"""Tests for the DEMO_LITE profile and the Red package.  Run: pytest -q"""

import copy, json, os, subprocess, sys
import pytest
from pypdf import PdfReader

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import red_package as rp
import triage
from scenarios import (
    LITE_AMBER,
    LITE_GREEN,
    LITE_NO_ANSWER,
    LITE_RED,
    GREEN,
    VOICE_NOTE_TRANSLATION,
    make_lite,
)

ROOT = os.path.join(os.path.dirname(__file__), "..")
SEED = json.load(open(os.path.join(ROOT, "seed.json")))
RED, AMB, GRN = "TIER_1_RED", "TIER_2_AMBER", "TIER_3_GREEN"
LITE = "DEMO_LITE"


def run(p, seed=SEED):
    return triage.triage(seed, p, profile=LITE)


def event(day, **sym):
    s = {"headache": False, "nausea": False, "drowsiness": False, "arm_pain": False}
    s.update(sym)
    return {"event_id": "EVT-T", "timestamp": f"2026-10-{day:02d}T09:00:00+05:30", "symptoms_present": s}


# ------------------------------------------------------------- DEMO_LITE profile
def test_L01_green_with_signed_instruction():
    r = run(LITE_GREEN)
    assert r["tier"] == GRN and r["reason_codes"] == [] and r["protocol_profile"] == LITE
    assert r["repeat_instruction_id"] == "INST-2026-10-19-01"


def test_L02_amber_uses_her_history():
    r = run(LITE_AMBER)
    assert r["tier"] == AMB
    assert set(r["reason_codes"]) == {
        "AMBER_BANGLES_TIGHTER_THAN_BASELINE",
        "AMBER_HEADACHE_RISE_2_PLUS",
        "AMBER_HEADACHE_WORSE_THAN_LAST_TIME",
        "AMBER_NAUSEA_DESPITE_MEALS",
    }


def test_L03_red_replay_stops_at_the_arm_question():
    r = run(LITE_RED)
    assert r["tier"] == RED and r["reason_codes"] == ["RED_ARM_RED_OR_HOT"] and r["confirmed_danger"] is True


def test_L04_no_answer_twice():
    r = run(LITE_NO_ANSWER)
    assert r["tier"] == RED and r["reason_codes"] == ["RED_NO_ANSWER_2X"]


def test_L05_questions_outside_the_lite_set_are_ignored_not_unconfirmed():
    p = copy.deepcopy(LITE_GREEN)
    for f in ("short_of_breath", "blurred_vision", "shaking_chills", "drowsy_most_of_today", "arm_pain"):
        p["answers"][f] = None  # junk from the extractor
    assert run(p)["tier"] == GRN
    p["answers"]["blurred_vision"] = "YES"  # even a YES on an unasked question cannot fire a rule
    assert run(p)["tier"] == GRN and run(p)["decision_inputs"]["answers"]["blurred_vision"] == "NOT_ASKED"


@pytest.mark.parametrize(
    "field", ["slurred_or_confused", "cannot_stay_awake", "chest_pain", "arm_red_or_hot", "vomiting_count"]
)
def test_L06_unclear_danger_answer_is_red_unconfirmed(field):
    r = run(make_lite(**{field: None}))
    assert r["tier"] == RED and r["confirmed_danger"] is False


@pytest.mark.parametrize(
    "field", ["bangles_tighter", "headache_present", "nausea_since_yesterday", "thermometer_used"]
)
def test_L07_unclear_amber_answer_is_amber(field):
    assert run(make_lite(**{field: None}))["tier"] in (AMB, RED)


def test_L08_third_headache_in_14_days():
    s = copy.deepcopy(SEED)
    s["events"].append(event(22, headache=True))
    assert "AMBER_RECURRING_3X_14D_HEADACHE" in run(LITE_GREEN, s)["reason_codes"]


def test_L09_thermometer_rules_still_work():
    assert run(make_lite(thermometer_used="NO"))["reason_codes"] == ["AMBER_NO_THERMOMETER_WITH_SYMPTOMS"]
    assert run(make_lite(temperature_value=100.4))["tier"] == RED
    assert run(make_lite(temperature_value=100.3))["tier"] == GRN


def test_L10_full_profile_unchanged_and_profile_recorded():
    assert triage.triage(SEED, GREEN)["protocol_profile"] == "FULL"
    assert triage.triage(SEED, GREEN, profile="NOPE")["reason_codes"] == ["RED_SYSTEM_FAULT"]


# ------------------------------------------------------------- the Red package
FORBIDDEN = [
    "suspected",
    "likely",
    "stage 1",
    "recommended",
    "linked to",
    "due to",
    "caused by",
    "grade",
    "ambulance",
    "http",
    "maps",
]


@pytest.fixture(scope="module")
def pkg(tmp_path_factory):
    out = tmp_path_factory.mktemp("pkg")
    red = rp.build_red_package(SEED, run(LITE_RED), str(out / "red"), "27 Oct 2026 10:16")
    noans = rp.build_red_package(
        SEED, run(LITE_NO_ANSWER), str(out / "noans"), "27 Oct 2026 10:19", VOICE_NOTE_TRANSLATION
    )
    return red, noans


def pdf_text(path):
    return "\n".join(p.extract_text() for p in PdfReader(path).pages)


def test_P01_message_tells_family_to_go_to_emergency():
    for p, kind in ((LITE_RED, "CONFIRMED"), (LITE_NO_ANSWER, "NO_ANSWER")):
        m = rp.caregiver_message(SEED, run(p))
        assert m["kind"] == kind and m["template_id"] == "TPL_WA_RED_CAREGIVER_V1"
        assert "nearest emergency department now" in m["english"] and "attached summary" in m["english"]
        assert not any(w in m["english"].lower() for w in FORBIDDEN)
        assert "{" not in m["english"] and "{" not in m["tamil_draft"]


def test_P02_which_red_cases_send_automatically(pkg):
    red, noans = pkg
    assert red["auto_send"] and noans["auto_send"]
    unsure = run(make_lite(slurred_or_confused=None))
    assert rp.red_kind(unsure) == "UNCONFIRMED" and "UNCONFIRMED" not in rp.PACKAGE_CONFIG["auto_send_kinds"]


def test_P03_doctor_note_is_facts_only(pkg):
    for r in pkg:
        n = r["doctor_note"]
        assert "SYN-BC-000142" in n and "Not yet known" in n and "30 minutes" in n
        assert not any(w in n.lower() for w in FORBIDDEN)


def test_P04_coordinator_task(pkg):
    t = pkg[0]["coordinator_task"]
    assert t["due_minutes"] == 30 and t["text"].startswith("Call Karthik")
    assert "REACHED" in t["text"] and "NOT REACHABLE" in t["text"]


def test_P05_pdf_helps_a_doctor_at_another_hospital(pkg):
    txt = pdf_text(pkg[0]["pdf_path"])
    for must in [
        "SYNTHETIC DEMO",
        "SYN-BC-000142",
        "stage IIB",
        "ER positive",
        "mastectomy",
        "axillary",
        "Letrozole",
        "Shelcal-HD",
        "Neurobion",
        "2026-10-10",
        "2026-10-19",
        "only after a full meal",
        "no swelling, bangles loose",
        "Left arm reported as red or hot",
        "Allergies",
        "blood pressure",
        "Senior Oncologist",
        "HOSPITAL-CALLBACK-NUMBER-PLACEHOLDER",
        "does not diagnose or advise",
    ]:
        assert must in txt.replace("\n", " "), must


def test_P06_pdf_is_short_and_clean(pkg):
    for r in pkg:
        assert len(PdfReader(r["pdf_path"]).pages) <= 2
        txt = pdf_text(r["pdf_path"]).lower()
        assert not any(w in txt for w in FORBIDDEN)


def test_P07_no_answer_pdf_has_the_voice_note_and_no_invented_answers(pkg):
    txt = pdf_text(pkg[1]["pdf_path"]).replace("\n", " ")
    assert "machine translation from Tamil" in txt and "very sleepy" in txt and "could not be reached" in txt
    assert "Thermometer" not in txt


def test_P08_audit_rows(pkg):
    acts = [a["action"] for a in pkg[0]["audit_rows"]]
    assert acts == ["TEMPLATE_SENT", "DOCTOR_NOTE_CREATED", "COORDINATOR_TASK_CREATED"]
    assert all(a["actor_type"] in ("AGENT", "SYSTEM") for a in pkg[0]["audit_rows"])


def test_P09_every_red_reason_has_plain_words():
    import re

    codes = set(re.findall(r'"(RED_[A-Z0-9_]+)"', open(os.path.join(ROOT, "triage.py")).read()))
    codes -= set(triage.ACTIONS)  # action keys such as RED_CONFIRMED are not reason codes
    assert codes <= set(rp.REASON_PLAIN), codes - set(rp.REASON_PLAIN)


# ------------------------------------------------------------- the "why" panel
import why_panel


def test_W01_amber_why_lines_compare_with_history():
    lines = why_panel.why_lines(SEED, run(LITE_AMBER))
    text = " ".join(lines)
    assert "no swelling and loose bangles on 2026-10-10" in text and "Today: bangles tighter" in text
    assert "2 out of 10 on 2026-10-19. Today: 5 out of 10" in text
    assert "as the doctor advised on 2026-10-19" in text
    assert not any(w in text.lower() for w in ("likely", "suspected", "because", "due to", "caused"))


def test_W02_red_and_green_why_lines():
    assert why_panel.why_lines(SEED, run(LITE_RED)) == ["Left arm reported as red or hot to touch"]
    assert why_panel.why_lines(SEED, run(LITE_GREEN))[0].startswith("No rule fired.")


def test_W03_lite_facts_do_not_claim_nausea_settled():
    from triage import facts_text

    assert "settled" not in facts_text(run(LITE_GREEN)) and "Nausea since yesterday" in facts_text(
        run(LITE_GREEN)
    )
    assert facts_text(triage.triage(SEED, GREEN)).count("settled") == 1  # full profile still says it
