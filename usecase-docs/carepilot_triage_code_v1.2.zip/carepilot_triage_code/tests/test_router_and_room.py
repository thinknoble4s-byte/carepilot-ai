"""Tests for the router (what to ask) and the Triage Room (what staff see and may do).  Run: pytest -q"""
import copy
import itertools
import json
import math
import os
import struct
import sys
import wave

import pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import router, triage, triage_room as room
from questions import BANK, BY_ID
from scenarios import (LITE_NO_ANSWER, make_lite, GREEN, ROUTED_AMBER, ROUTED_GREEN, ROUTED_RASH, ROUTED_RED, ROUTED_SEVERE_ARM, ROUTED_TIRED,
                       TAGS_BROKEN, TAGS_HERO, TAGS_SEVERE_ARM, TAGS_SHOPPING, TAGS_TIRED, make_routed)

ROOT = os.path.join(os.path.dirname(__file__), "..")
SEED = json.load(open(os.path.join(ROOT, "seed.json")))
SCHEMA = json.load(open(os.path.join(ROOT, "extraction_schema.json")))
RED, AMB, GRN = "TIER_1_RED", "TIER_2_AMBER", "TIER_3_GREEN"


def ev(plan_payload, seed=SEED):
    plan, payload = plan_payload
    return router.evaluate(seed, plan, payload)


# ------------------------------------------------------------- routing
def test_R01_hero_message_gets_core_history_and_four_modules():
    plan = router.select_questions(SEED, TAGS_HERO)
    ids = plan["question_ids"]
    assert plan["route"] == "TRIAGE" and plan["profile"] == "ROUTED" and len(ids) == 16
    assert ids[:6] == router.CORE + router.HISTORY_ARM  # danger core first, then her arm history
    assert {"headache", "nausea_vomiting", "sleepiness", "arm_pain"} <= set(plan["modules"])


def test_R02_a_message_that_is_not_about_health_gets_one_standard_reply():
    plan = router.select_questions(SEED, TAGS_SHOPPING)
    assert plan["route"] == "STANDARD_REPLY" and plan["question_ids"] == [] and plan["profile"] is None
    assert plan["reply"]["template_id"] == "TPL_WA_NOT_HEALTH_V1" and "only for health concerns" in plan["reply"]["english"]
    assert "{" not in plan["reply"]["english"] and "{" not in plan["reply"]["tamil_draft"]


@pytest.mark.parametrize("tags", [
    {"health_related": "NO", "symptoms": ["headache"], "severity_word": "NONE"},   # says "no" but names a symptom
    {"health_related": "NO", "symptoms": [], "severity_word": "SEVERE"},           # says "no" but calls it severe
    {"health_related": "UNSURE", "symptoms": [], "severity_word": "NONE"},
    {"health_related": "YES", "symptoms": [], "severity_word": "NONE"},
])  # fmt: skip
def test_R03_anything_that_might_be_health_is_triaged(tags):
    assert router.select_questions(SEED, tags)["route"] == "TRIAGE"


@pytest.mark.parametrize("bad", [TAGS_BROKEN, None, {}, {"health_related": "MAYBE", "symptoms": []}, {"health_related": "YES", "symptoms": "x"}])
def test_R04_unusable_tags_fall_back_to_the_fixed_twelve(bad):
    plan = router.select_questions(SEED, bad)
    assert plan["route"] == "TRIAGE" and plan["profile"] == "DEMO_LITE" and len(plan["question_ids"]) == 12
    assert plan["active_fields"] == triage.LITE_FIELDS


def test_R05_a_symptom_we_have_no_questions_for_is_never_ignored():
    plan, payload = ROUTED_RASH
    assert plan["floors"] == ["AMBER_OTHER_SYMPTOM_REPORTED"]
    r = router.evaluate(SEED, plan, payload)
    assert r["tier"] == AMB and r["action_code"] == "COORDINATOR_IMMEDIATE_CALLBACK"  # a nurse calls within 15 minutes


def test_R06_the_danger_core_is_never_skipped_for_any_mix_of_tags():
    tags = [t for t in router.SYMPTOM_TAGS]
    for n in range(0, 4):
        for combo in itertools.combinations(tags, n):
            plan = router.select_questions(SEED, {"health_related": "YES", "symptoms": list(combo), "severity_word": "NONE"})
            if combo:
                assert plan["question_ids"][: len(router.CORE)] == router.CORE, combo


def test_R07_every_asked_field_is_in_the_schema_and_the_active_set_matches_the_bank():
    props = SCHEMA["properties"]["answers"]["properties"]
    for q in BANK:
        assert q["id"] in router.FALLBACK or q["id"] in sum(router.MODULES.values(), []) + router.CORE + router.HISTORY_ARM
        for f in q["fields"]:
            assert f in props, f
    plan = router.select_questions(SEED, TAGS_HERO)
    assert plan["active_fields"] == {f for q in plan["question_ids"] for f in BY_ID[q]["fields"]}


def test_R08_history_question_only_when_her_record_has_the_baseline():
    s = copy.deepcopy(SEED); del s["longitudinal_baseline"]["last_recorded_left_arm"]
    assert "Q_BANGLES" not in router.select_questions(s, TAGS_HERO)["question_ids"]
    assert "Q_BANGLES" in router.select_questions(SEED, TAGS_HERO)["question_ids"]


# ------------------------------------------------------------- the same engine, different questions, different results
def test_E01_hero_green_amber_red():
    g, a, r = ev(ROUTED_GREEN), ev(ROUTED_AMBER), ev(ROUTED_RED)
    assert g["tier"] == GRN and g["repeat_instruction_id"] == "INST-2026-10-19-01"
    assert a["tier"] == AMB and set(a["reason_codes"]) == {
        "AMBER_BANGLES_TIGHTER_THAN_BASELINE", "AMBER_DROWSY_MOST_OF_TODAY", "AMBER_HEADACHE_RISE_2_PLUS",
        "AMBER_HEADACHE_WORSE_THAN_LAST_TIME", "AMBER_NAUSEA_DESPITE_MEALS"}  # fmt: skip
    assert r["tier"] == RED and r["reason_codes"] == ["RED_ARM_RED_OR_HOT"] and r["confirmed_danger"]


def test_E02_severe_arm_pain_can_never_be_green_even_with_mild_answers():
    plan, payload = ROUTED_SEVERE_ARM
    assert len(plan["question_ids"]) == 8 and payload["answers"]["arm_pain_score"] == 3
    r = ev(ROUTED_SEVERE_ARM)
    assert r["tier"] == AMB and r["reason_codes"] == ["AMBER_PATIENT_SAYS_SEVERE"]


def test_E03_a_floor_never_lowers_anything():
    r = ev(make_routed(TAGS_SEVERE_ARM, arm_red_or_hot="YES"))
    assert r["tier"] == RED and "AMBER_PATIENT_SAYS_SEVERE" not in r["reason_codes"]


@pytest.mark.parametrize("changes,code", [({"arm_pain_score": 7}, "AMBER_ARM_PAIN_7_PLUS"),
                                          ({"arm_pain_sudden": "YES"}, "AMBER_ARM_PAIN_SUDDEN_ONSET"),
                                          ({"arm_pain_score": None}, "AMBER_CANNOT_CONFIRM"),
                                          ({"arm_pain_sudden": "UNKNOWN"}, "AMBER_CANNOT_CONFIRM")])  # fmt: skip
def test_E04_arm_pain_module(changes, code):
    r = ev(make_routed({"health_related": "YES", "symptoms": ["arm_pain"], "severity_word": "NONE"}, **changes))
    assert r["tier"] == AMB and code in r["reason_codes"]


def test_E05_tiredness_module():
    assert ev(ROUTED_TIRED)["tier"] == GRN and len(ROUTED_TIRED[0]["question_ids"]) == 8
    assert "AMBER_TIREDNESS_7_DAYS_PLUS" in ev(make_routed(TAGS_TIRED, tired_days=9))["reason_codes"]
    assert "AMBER_TIREDNESS_7_DAYS_PLUS" not in ev(make_routed(TAGS_TIRED, tired_days=6))["reason_codes"]
    assert "AMBER_TIREDNESS_GETTING_WORSE" in ev(make_routed(TAGS_TIRED, tired_getting_worse="YES"))["reason_codes"]


def test_E06_i_feel_ok_never_replaces_the_danger_core():
    plan, payload = make_routed(TAGS_TIRED, chest_pain="YES", meta={"stopped_after_danger_sign": True})
    assert router.evaluate(SEED, plan, payload)["tier"] == RED


def test_E07_questions_not_asked_are_recorded_as_not_asked_and_never_crash():
    r = ev(ROUTED_TIRED)
    a = r["decision_inputs"]["answers"]
    assert a["vomiting_count"] == "NOT_ASKED" and a["headache_present"] == "NOT_ASKED" and a["arm_pain_score"] == "NOT_ASKED"


def test_E08_answers_to_questions_that_were_not_asked_cannot_fire_rules():
    plan, payload = make_routed(TAGS_TIRED)
    payload["answers"]["headache_present"] = "YES"; payload["answers"]["vomiting_count"] = 9  # fmt: skip
    assert router.evaluate(SEED, plan, payload)["tier"] == GRN


def test_E09_an_unclear_answer_to_an_asked_question_is_never_green():
    plan, payload = make_routed(TAGS_HERO, drowsy_most_of_today=None)
    assert router.evaluate(SEED, plan, payload)["tier"] in (AMB, RED)
    plan, payload = make_routed(TAGS_HERO, chest_pain=None)
    assert router.evaluate(SEED, plan, payload)["tier"] == RED


def test_E10_routed_profile_without_an_active_set_is_a_system_fault():
    r = triage.triage(SEED, ROUTED_GREEN[1], profile="ROUTED")
    assert r["tier"] == RED and r["reason_codes"] == ["RED_SYSTEM_FAULT"]


def test_E11_full_profile_does_not_ask_the_router_only_questions():
    r = triage.triage(SEED, GREEN)
    a = r["decision_inputs"]["answers"]
    assert r["tier"] == GRN and a["arm_pain_score"] == "NOT_ASKED" and a["tired_days"] == "NOT_ASKED"


def test_E12_recurrence_still_uses_her_history_in_routed_calls():
    s = copy.deepcopy(SEED)
    s["events"].append(
        {"event_id": "E", "timestamp": "2026-10-22T09:00:00+05:30",
         "symptoms_present": {"headache": True, "nausea": False, "drowsiness": False, "arm_pain": False}}
    )  # fmt: skip
    plan, payload = ROUTED_GREEN
    assert "AMBER_RECURRING_3X_14D_HEADACHE" in router.evaluate(s, plan, payload)["reason_codes"]


# ------------------------------------------------------------- the Triage Room
def tone(path, seconds, rate=8000):
    with wave.open(path, "wb") as w:
        w.setnchannels(1); w.setsampwidth(2); w.setframerate(rate)  # fmt: skip
        n = int(seconds * rate)
        w.writeframes(b"".join(struct.pack("<h", int(8000 * math.sin(2 * math.pi * 440 * i / rate))) for i in range(n)))


def ticket_for(case, seq=1, **kw):
    plan, payload = case
    return room.build_ticket(SEED, plan, router.evaluate(SEED, plan, payload), seq, "2026-10-27T10:19:00+05:30", **kw)


def test_T01_ticket_id():
    assert room.ticket_id("2026-10-27T10:19:00+05:30", 1) == "CP-20261027-0001"
    assert room.ticket_id("2026-11-07", 23) == "CP-20261107-0023"


def test_T02_amber_ticket_has_everything_the_screen_needs():
    t = ticket_for(ROUTED_AMBER)
    assert t["ticket_id"] == "CP-20261027-0001" and t["colour"] == "AMBER" and t["state"] == "OPEN" and t["due_minutes"] == 120
    assert t["protocol"]["status"] == "DRAFT_UNSIGNED" and len(t["questions_asked"]) == 16
    assert any("Bangles tighter" in l["text"] for l in t["summary_lines"]) and t["why_lines"]
    assert set(t["next_actions"]) == {"AI", "DOCTOR", "NURSE", "COORDINATOR"}
    assert "Physiotherapy referral" in t["next_actions"]["DOCTOR"]["buttons"] and t["next_actions"]["DOCTOR"]["due_minutes"] == 120


def test_T03_green_ticket_goes_to_the_digest_and_only_a_coordinator_acknowledges():
    t = ticket_for(ROUTED_GREEN)
    assert t["state"] == "IN_DIGEST" and t["colour"] == "GREEN"
    assert t["next_actions"]["COORDINATOR"]["buttons"] == ["Acknowledge", "Reopen"]
    with pytest.raises(ValueError):
        room.move(copy.deepcopy(t), "ACKNOWLEDGED", "DOCTOR_ON_DUTY")
    room.move(t, "ACKNOWLEDGED", "COORDINATOR")
    assert t["state"] == "ACKNOWLEDGED" and t["audit"][-1]["actor_type"] == "PERSON"


def test_T04_only_the_er_doctor_closes_red():
    t = ticket_for(ROUTED_RED)
    for who in ("COORDINATOR", "DOCTOR_ON_DUTY", "AGENT"):
        with pytest.raises(ValueError):
            room.move(copy.deepcopy(t), "ACKNOWLEDGED", who)  # a nurse or the ER doctor acknowledges Red
    room.move(t, "ACKNOWLEDGED", "NURSE")
    room.move(t, "OUTCOME_LOGGED", "ER_DOCTOR")
    for who in ("COORDINATOR", "DOCTOR_ON_DUTY", "NURSE", "AGENT"):
        with pytest.raises(ValueError):
            room.move(copy.deepcopy(t), "CLOSED", who)
    room.move(t, "CLOSED", "ER_DOCTOR")
    assert t["state"] == "CLOSED"


def test_T05_amber_closes_only_after_the_agent_proposes_and_a_person_confirms():
    t = ticket_for(ROUTED_AMBER)
    room.move(t, "ACKNOWLEDGED", "DOCTOR_ON_DUTY"); room.move(t, "OUTCOME_LOGGED", "DOCTOR_ON_DUTY")  # fmt: skip
    with pytest.raises(ValueError):
        room.move(copy.deepcopy(t), "CLOSED", "DOCTOR_ON_DUTY")  # not proposed yet
    with pytest.raises(ValueError):
        room.move(copy.deepcopy(t), "CLOSURE_PROPOSED", "DOCTOR_ON_DUTY")  # only the agent proposes
    room.move(t, "CLOSURE_PROPOSED", "AGENT")
    with pytest.raises(ValueError):
        room.move(copy.deepcopy(t), "CLOSED", "AGENT")  # the agent never closes Amber
    room.move(t, "CLOSED", "DOCTOR_ON_DUTY")
    assert [a["action"] for a in t["audit"]][-1] == "STATE_CLOSED"


def test_T06_who_may_change_a_tier():
    t = ticket_for(ROUTED_GREEN)
    with pytest.raises(ValueError):
        room.change_tier(copy.deepcopy(t), "COORDINATOR", "TIER_2_AMBER", "")  # reason required
    room.change_tier(t, "COORDINATOR", "TIER_2_AMBER", "She sounded breathless on the phone")  # anyone may raise
    assert t["colour"] == "AMBER" and t["audit"][-1]["reason"]
    for who in ("COORDINATOR", "NURSE", "AGENT"):
        with pytest.raises(ValueError):
            room.change_tier(copy.deepcopy(t), who, "TIER_3_GREEN", "looks fine")
    room.change_tier(t, "DOCTOR_ON_DUTY", "TIER_3_GREEN", "Spoke to her; settled")
    red = ticket_for(ROUTED_RED)
    with pytest.raises(ValueError):
        room.change_tier(copy.deepcopy(red), "DOCTOR_ON_DUTY", "TIER_2_AMBER", "x")
    room.change_tier(red, "ER_DOCTOR", "TIER_2_AMBER", "Seen in emergency; stable")


def test_T07_next_actions_by_kind():
    red = room.next_actions(router.evaluate(SEED, *ROUTED_RED))
    assert red["COORDINATOR"]["due_minutes"] == 30 and "NOT REACHABLE" in red["COORDINATOR"]["buttons"]
    assert "Close case" in red["DOCTOR"]["buttons"]
    na = room.next_actions(triage.triage(SEED, LITE_NO_ANSWER, profile="DEMO_LITE"))
    assert na["AI"]["text"].startswith("Two calls were not answered")
    unsure = room.next_actions(triage.triage(SEED, make_lite(slurred_or_confused=None), profile="DEMO_LITE"))
    assert "Send emergency package" in unsure["NURSE"]["buttons"] and "No family message" in unsure["AI"]["text"]
    nurse = room.next_actions(router.evaluate(SEED, *ROUTED_RASH))
    assert nurse["NURSE"]["due_minutes"] == 15


def test_T08_one_audio_file_for_the_whole_conversation(tmp_path):
    clips = []
    for i, (sp, qid, secs) in enumerate([("AI", "Q_SLURRED", 1.0), ("PATIENT", "Q_SLURRED", 0.5), ("AI", "Q_HEAD_SCORE", 1.5), ("PATIENT", "Q_HEAD_SCORE", 0.5)]):
        p = str(tmp_path / f"c{i}.wav"); tone(p, secs); clips.append({"speaker": sp, "question_id": qid, "path": p})  # fmt: skip
    out = str(tmp_path / "conversation.wav")
    tl = room.stitch_conversation_wav(clips, out, gap_s=0.5)
    assert [t["start_s"] for t in tl] == [0.0, 1.5, 2.5, 4.5] and tl[-1]["end_s"] == 5.0
    with wave.open(out, "rb") as w:
        assert abs(w.getnframes() / w.getframerate() - 5.5) < 0.01  # 3.5 s of speech + 4 gaps of 0.5 s
    bad = str(tmp_path / "other.wav"); tone(bad, 0.5, rate=16000)
    with pytest.raises(ValueError):
        room.stitch_conversation_wav(clips + [{"speaker": "AI", "path": bad}], str(tmp_path / "x.wav"))


def test_T09_summary_lines_jump_to_the_moment_she_said_it(tmp_path):
    tl = [{"speaker": "PATIENT", "question_id": "Q_HEAD_SCORE", "start_s": 12.5, "end_s": 14.0},
          {"speaker": "PATIENT", "question_id": "Q_BANGLES", "start_s": 20.0, "end_s": 21.0}]  # fmt: skip
    t = ticket_for(ROUTED_AMBER, timeline=tl, audio_path="conversation.wav")
    by_text = {l["text"]: l for l in t["summary_lines"]}
    assert by_text["Headache 5/10"]["audio_start_s"] == 12.5 and by_text["Bangles tighter than before"]["audio_start_s"] == 20.0
    assert t["conversation_audio"]["path"] == "conversation.wav"


def test_T10_the_ticket_text_is_facts_only():
    for case in (ROUTED_AMBER, ROUTED_GREEN, ROUTED_RED, ROUTED_SEVERE_ARM):
        t = ticket_for(case)
        text = json.dumps([t["summary_lines"], t["why_lines"], t["next_actions"]]).lower()
        assert not any(w in text for w in ("suspected", "likely", "diagnos", "grade", "caused by", "due to", "linked to"))


def test_W10_every_amber_code_the_engine_can_return_has_a_plain_sentence():
    import re
    import why_panel
    src = open(os.path.join(ROOT, "triage.py")).read() + open(os.path.join(ROOT, "router.py")).read()
    codes = set(re.findall(r'"(AMBER_[A-Z0-9_]+)"', src)) - {"AMBER_HUMAN_NOW", "AMBER_TODAY"}
    codes = {c for c in codes if not c.startswith("AMBER_RECURRING")} | {"AMBER_RECURRING_3X_14D_HEADACHE"}
    for code in sorted(codes):
        fake = {"reason_codes": [code], "tier": AMB, "decision_inputs": {"answers": {"vomiting_count": 3, "arm_pain_score": 8, "tired_days": 9}, "headache_score_used": 5, "rolling_counts": {}, "unconfirmed_fields": ["x"]}}
        line = why_panel.why_lines(SEED, fake)[0]
        assert line != code, code
