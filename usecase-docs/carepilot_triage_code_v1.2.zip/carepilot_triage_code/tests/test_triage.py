"""Run with:  pytest -q      (from the folder that holds triage.py)"""

import copy, json, sys, os
import jsonschema, pytest

sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import triage
from triage import triage as run, evaluate_followup, render_brief, rolling_counts
from scenarios import GREEN, AMBER, RED_A, RED_B, RED_MULTI, make

ROOT = os.path.join(os.path.dirname(__file__), "..")
SEED = json.load(open(os.path.join(ROOT, "seed.json")))
SCHEMA = json.load(open(os.path.join(ROOT, "extraction_schema.json")))
RED, AMB, GRN = "TIER_1_RED", "TIER_2_AMBER", "TIER_3_GREEN"


def seed_with(extra_events):
    s = copy.deepcopy(SEED)
    s["events"] += extra_events
    return s


def event(day, **sym):
    p = {"headache": False, "nausea": False, "drowsiness": False, "arm_pain": False}
    p.update(sym)
    return {
        "event_id": "EVT-TEST",
        "timestamp": f"2026-10-{day:02d}T09:00:00+05:30",
        "symptoms_present": p,
    }


# ---------- T-01 to T-04: the three scenarios
def test_T01_green_canonical():
    r = run(SEED, GREEN)
    assert r["tier"] == GRN and r["reason_codes"] == []
    assert r["action_code"] == "GREEN_COACH_AND_FOLLOWUP_24H"
    assert r["repeat_instruction_id"] == "INST-2026-10-19-01"


def test_T02_amber():
    r = run(SEED, AMBER)
    assert r["tier"] == AMB and r["action_code"] == "DOCTOR_CALLBACK_2H"
    for code in [
        "AMBER_BANGLES_TIGHTER_THAN_BASELINE",
        "AMBER_HEADACHE_WORSE_THAN_LAST_TIME",
        "AMBER_HEADACHE_RISE_2_PLUS",
        "AMBER_HEADACHE_48H_PLUS",
        "AMBER_NAUSEA_DESPITE_MEALS",
        "AMBER_DROWSY_MOST_OF_TODAY",
        "AMBER_THREE_OR_MORE_SYMPTOMS_NOW",
        "AMBER_ARM_SWOLLEN",
    ]:
        assert code in r["reason_codes"]


def test_T03_red_confirmed_stops_at_first_danger_sign():
    r = run(SEED, RED_A)
    assert (
        r["tier"] == RED
        and r["confirmed_danger"] is True
        and r["action_code"] == "ER_DESK_HANDOFF_SIMULATED"
    )
    assert r["reason_codes"] == [
        "RED_SLURRED_OR_CONFUSED"
    ]  # nothing else was asked, so nothing else is "unconfirmed"
    assert r["decision_inputs"]["sender_role"] == "CAREGIVER"


def test_T03b_stop_flag_without_a_danger_answer_is_a_system_fault():
    r = run(SEED, make(meta={"stopped_after_danger_sign": True}))
    assert r["tier"] == RED and r["reason_codes"] == ["RED_SYSTEM_FAULT"]


def test_T04_red_arm_infection_signs_stop_the_call():
    r = run(SEED, RED_B)
    assert (
        r["tier"] == RED
        and r["reason_codes"] == ["RED_ARM_RED_OR_HOT"]
        and r["confirmed_danger"] is True
    )


def test_T04b_several_danger_answers_at_once():
    r = run(SEED, RED_MULTI)
    assert {"RED_ARM_RED_OR_HOT", "RED_SHAKING_CHILLS", "RED_FEVER_100_4F_PLUS"} <= set(
        r["reason_codes"]
    )


# ---------- T-05: Green needs a real thermometer reading
def test_T05_no_thermometer_is_not_green():
    r = run(SEED, make(thermometer_used="NO"))
    assert r["tier"] == AMB and "AMBER_NO_THERMOMETER_WITH_SYMPTOMS" in r["reason_codes"]


def test_T05b_feels_hot_no_thermometer():
    r = run(SEED, make(thermometer_used="NO", feels_hot="YES"))
    assert r["tier"] == AMB and "AMBER_FEELS_HOT_NO_THERMOMETER" in r["reason_codes"]


def test_T05c_no_symptoms_no_thermometer_is_green():
    a = make(
        thermometer_used="NO",
        headache_present="NO",
        nausea_since_yesterday="NO",
        arm_pain="NO",
        vomiting_count=0,
    )
    assert run(SEED, a)["tier"] == GRN


# ---------- T-06: fever boundary (the number decides, not the model)
@pytest.mark.parametrize(
    "value,tier", [(100.3, GRN), (100.4, RED), (99.0, GRN), (37.9, GRN), (38.0, RED), (12, AMB)]
)
def test_T06_fever_boundary(value, tier):
    assert run(SEED, make(temperature_value=value))["tier"] == tier


# ---------- T-07: vomiting counts
@pytest.mark.parametrize("n,tier", [(0, GRN), (1, GRN), (2, AMB), (3, AMB), (5, AMB), (6, RED)])
def test_T07_vomiting(n, tier):
    assert run(SEED, make(vomiting_count=n))["tier"] == tier


# ---------- T-08: headache rules
@pytest.mark.parametrize(
    "changes,tier",
    [
        ({"headache_score": 3}, GRN),
        ({"headache_score": 4}, AMB),
        ({"headache_score": 7}, RED),
        ({"headache_hours": 47}, GRN),
        ({"headache_hours": 48}, AMB),
        ({"headache_worst_on_waking": "YES"}, RED),
        ({"headache_worse_than_last_time": "YES"}, AMB),
        ({"headache_score": None, "headache_band": "MILD"}, GRN),
        ({"headache_score": None, "headache_band": "MEDIUM"}, AMB),
        ({"headache_score": None, "headache_band": "STRONG"}, RED),
        ({"headache_score": None, "headache_band": None}, RED),
    ],
)
def test_T08_headache(changes, tier):
    assert run(SEED, make(**changes))["tier"] == tier


# ---------- T-09: 3 times in 14 days, any of the four symptoms; day 14 counts, day 15 does not
@pytest.mark.parametrize(
    "symptom,answers",
    [
        ("headache", {}),
        ("nausea", {}),
        ("drowsiness", {"drowsy_most_of_today": "YES"}),
        ("arm_pain", {}),
    ],
)
def test_T09_recurrence(symptom, answers):
    s = seed_with([event(22, **{symptom: True}), event(24, **{symptom: True})])
    base = {"headache_present": "NO", "nausea_since_yesterday": "NO", "arm_pain": "NO"}
    base.update(
        {
            "headache": {"headache_present": "YES"},
            "nausea": {"nausea_since_yesterday": "YES"},
            "arm_pain": {"arm_pain": "YES"},
            "drowsiness": {},
        }[symptom]
    )
    base.update(answers)
    r = run(s, make(**base, headache_hours=3))
    assert "AMBER_RECURRING_3X_14D_" + symptom.upper() in r["reason_codes"]


def test_T09b_window_edges():
    day14 = seed_with([event(13, headache=True)])
    day15 = seed_with([event(12, headache=True)])  # 27 Oct minus 14 / 15 days
    assert (
        rolling_counts(day14["events"], __import__("datetime").date(2026, 10, 27))["headache"] == 2
    )
    assert (
        rolling_counts(day15["events"], __import__("datetime").date(2026, 10, 27))["headache"] == 1
    )
    assert (
        rolling_counts(SEED["events"], __import__("datetime").date(2026, 10, 27))["arm_pain"] == 0
    )  # 10 Oct is 17 days ago


def test_T09c_edge_case_1_from_the_guide():
    s = seed_with([event(22, headache=True)])  # prior 19 Oct + this one = 2 earlier headaches
    r = run(s, GREEN)
    assert r["tier"] == AMB and "AMBER_RECURRING_3X_14D_HEADACHE" in r["reason_codes"]


# ---------- T-10: missing or unclear answers never give Green and never crash
RED_FIELDS = [
    "slurred_or_confused",
    "blurred_vision",
    "unsteady_or_dizzy_walking",
    "cannot_stay_awake",
    "shaking_chills",
    "arm_red_or_hot",
    "chest_pain",
    "short_of_breath",
    "headache_worst_on_waking",
    "headache_score",
    "vomiting_count",
    "can_keep_liquids_down",
]
AMBER_FIELDS = [
    "drowsy_most_of_today",
    "headache_present",
    "headache_worse_than_last_time",
    "headache_hours",
    "feels_hot",
    "thermometer_used",
    "nausea_since_yesterday",
    "nausea_now",
    "took_supplements_after_full_meals",
    "skin_break_left_arm",
    "bangles_tighter",
    "arm_swollen",
    "arm_pain",
]


@pytest.mark.parametrize("field", RED_FIELDS)
@pytest.mark.parametrize("bad", [None, "UNKNOWN", "maybe"])
def test_T10_red_field_unclear_is_red_unconfirmed(field, bad):
    r = run(SEED, make(**{field: bad}))
    assert (
        r["tier"] == RED
        and r["confirmed_danger"] is False
        and "RED_CANNOT_CONFIRM_SAFE" in r["reason_codes"]
    )


@pytest.mark.parametrize("field", AMBER_FIELDS)
@pytest.mark.parametrize("bad", [None, "UNKNOWN"])
def test_T10_amber_field_unclear_is_at_least_amber(field, bad):
    r = run(SEED, make(**{field: bad}))
    assert r["tier"] in (AMB, RED)


def test_T10_skipped_follow_ups_under_a_clear_no_are_fine():
    a = make(
        headache_present="NO",
        headache_score=None,
        headache_hours=None,
        headache_worst_on_waking="NOT_ASKED",
        headache_worse_than_last_time="NOT_ASKED",
    )
    assert run(SEED, a)["tier"] == GRN


def test_T10_garbage_payloads():
    for bad in [
        {},
        {"call_metadata": {}},
        {"answers": {}},
        {"call_metadata": None, "answers": None},
        "text",
        None,
    ]:
        r = run(SEED, bad)
        assert r["tier"] == RED and r["reason_codes"] == ["RED_SYSTEM_FAULT"]


# ---------- T-11: call-level rules
def test_T11_no_answer_after_two_attempts():
    r = run(SEED, make(meta={"callback_answered": False, "callback_attempts": 2}))
    assert (
        r["tier"] == RED
        and r["action_code"] == "ALERT_NURSE_AND_CALL_CAREGIVER"
        and r["confirmed_danger"] is False
    )
    assert "ambulance" not in json.dumps(r).lower()


def test_T11_first_missed_call_means_retry():
    assert (
        run(SEED, make(meta={"callback_answered": False, "callback_attempts": 1}))["tier"]
        == "RETRY_CALL"
    )


def test_T11_nurse_key_is_human_now_not_a_false_red():
    r = run(
        SEED,
        {
            "call_metadata": {**GREEN["call_metadata"], "nurse_key_pressed": True},
            "answers": {"slurred_or_confused": "NO", "blurred_vision": "NO"},
        },
    )
    assert r["tier"] == AMB and r["action_code"] == "COORDINATOR_IMMEDIATE_CALLBACK"


def test_T11_nurse_key_never_hides_a_danger_sign():
    r = run(
        SEED,
        {
            "call_metadata": {**GREEN["call_metadata"], "nurse_key_pressed": True},
            "answers": {"slurred_or_confused": "YES"},
        },
    )
    assert r["tier"] == RED


def test_T11_unusable_transcript():
    r = run(SEED, make(meta={"transcript_usable": False}))
    assert r["tier"] == AMB and "AMBER_TRANSCRIPT_UNUSABLE" in r["reason_codes"]


def test_T11_who_is_speaking_unknown_or_caregiver_without_consent():
    assert run(SEED, make(meta={"sender_role": "UNKNOWN"}))["reason_codes"] == [
        "AMBER_ROLE_NOT_CONFIRMED"
    ]
    assert run(SEED, make(meta={"sender_role": "CAREGIVER", "caregiver_consent": False}))[
        "reason_codes"
    ] == ["AMBER_CAREGIVER_NO_CONSENT"]


# ---------- T-12: the 3-symptom guard counts symptoms present NOW, whatever the patient thinks the cause is
def test_T12_guard():
    two = make(headache_present="YES", arm_pain="YES")
    three = make(drowsy_most_of_today="YES", headache_present="YES", arm_pain="YES")
    assert run(SEED, two)["tier"] == GRN
    assert "AMBER_THREE_OR_MORE_SYMPTOMS_NOW" in run(SEED, three)["reason_codes"]


def test_T12b_skin_break_alone_is_amber():
    assert "AMBER_SKIN_BREAK_LEFT_ARM" in run(SEED, make(skin_break_left_arm="YES"))["reason_codes"]


# ---------- T-13: the instruction replay rule
def test_T13_replay_only_when_it_fits():
    assert run(SEED, GREEN)["repeat_instruction_id"] == "INST-2026-10-19-01"
    assert (
        run(
            SEED,
            make(
                nausea_since_yesterday="NO",
                nausea_now="NOT_ASKED",
                took_supplements_after_full_meals="NOT_ASKED",
            ),
        )["repeat_instruction_id"]
        is None
    )
    unsigned = copy.deepcopy(SEED)
    unsigned["clinician_repeatable_instructions"][0]["patient_repeatable"] = False
    assert run(unsigned, GREEN)["repeat_instruction_id"] is None


# ---------- T-14: 24-hour follow-up
def test_T14_followups():
    assert (
        evaluate_followup("GREEN", {"feeling": "BETTER", "anything_new": "NO"}, 1)["action_code"]
        == "CLOSED_BY_AGENT_IN_DIGEST"
    )
    assert (
        evaluate_followup("AMBER", {"feeling": "BETTER", "anything_new": "NO"}, 1)[
            "needs_human_close"
        ]
        is True
    )
    assert evaluate_followup("GREEN", {"feeling": "SAME", "anything_new": "NO"}, 1)["tier"] == AMB
    assert (
        evaluate_followup("GREEN", {"feeling": "BETTER", "anything_new": "UNKNOWN"}, 1)["tier"]
        == AMB
    )
    assert evaluate_followup("GREEN", None, 1)["status"] == "RETRY_CALL"
    assert evaluate_followup("GREEN", None, 2)["reason_codes"] == ["AMBER_NO_ANSWER_ON_FOLLOWUP"]


# ---------- T-15: contracts
def test_T15_schema_accepts_scenarios_and_rejects_drift():
    for p in (GREEN, AMBER, RED_A, RED_B, RED_MULTI):
        jsonschema.validate(p, SCHEMA)
    bad = copy.deepcopy(GREEN)
    bad["answers"]["bangle_tightness_vs_oct10_baseline"] = "YES"  # a date baked into a name
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(bad, SCHEMA)
    bad = copy.deepcopy(GREEN)
    del bad["answers"]["chest_pain"]
    with pytest.raises(jsonschema.ValidationError):
        jsonschema.validate(bad, SCHEMA)


def test_T15_same_input_same_output():
    assert run(SEED, AMBER) == run(copy.deepcopy(SEED), copy.deepcopy(AMBER))


def test_T15_engine_never_reads_the_wall_clock():
    import inspect

    src = inspect.getsource(triage)
    assert "datetime.now" not in src and "date.today" not in src and "time.time" not in src


REASON_PREFIXES = ("RED_", "AMBER_")


def test_T15_every_reason_code_is_a_known_code():
    codes = set()
    import re

    codes |= set(
        re.findall(r'"((?:RED|AMBER)_[A-Z0-9_]+)"', open(os.path.join(ROOT, "triage.py")).read())
    )
    for p in (GREEN, AMBER, RED_A, RED_B, RED_MULTI):
        for c in run(SEED, p)["reason_codes"]:
            assert c in codes or c.startswith("AMBER_RECURRING_3X_14D_")


# ---------- T-16: output wording and the brief
FORBIDDEN = [
    "grade",
    "suspected",
    "likely",
    "stage 1",
    "recommended",
    "diagnos",
    "linked to",
    "due to",
    "caused by",
]


def test_T16_no_clinical_wording_in_outputs():
    for p in (GREEN, AMBER, RED_A, RED_B, RED_MULTI):
        text = json.dumps(run(SEED, p)).lower()
        assert not any(w in text for w in FORBIDDEN)


def test_T16_brief_is_facts_only_and_has_sources():
    text = render_brief(SEED["patient_profile"], SEED["events"], "2027-01-02")
    assert "SYNTHETIC" in text and "cp://audio/" in text and "EVT-2026-10-19-002" in text
    assert not any(w in text.lower() for w in FORBIDDEN)


def test_T16_facts_text_is_mechanical():
    from triage import facts_text

    txt = facts_text(run(SEED, AMBER))
    assert "Headache 5/10 for 48 h" in txt and "Thermometer 98.4" in txt
    assert not any(w in txt.lower() for w in FORBIDDEN)
