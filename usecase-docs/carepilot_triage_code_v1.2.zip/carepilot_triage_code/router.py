"""The router: reads the tags the model made from the voice note and decides two things.

1. ROUTE: is this a health message (triage call) or not (one standard reply, nothing else)?
2. QUESTIONS: which questions to ask, from the bank, in a safe order.

The model only fills in tags from fixed lists. Plain rules below do all the choosing.
A question is never written by the model, and the danger core is never skipped.
"""

from questions import BANK, BY_ID

# The only symptom tags the model may return. Anything else becomes "other_symptom" (a nurse looks).
SYMPTOM_TAGS = (
    "headache", "nausea_vomiting", "sleepiness", "tiredness", "arm_pain", "arm_swelling_or_redness",
    "fever_chills", "chest_or_breathing", "dizziness_or_vision", "other_symptom",
)  # fmt: skip
HEALTH = ("YES", "NO", "UNSURE")

CORE = ["Q_SLURRED", "Q_AWAKE", "Q_CHEST", "Q_ARM_RED", "Q_TEMP"]  # always asked, in this order
HISTORY_ARM = ["Q_BANGLES"]  # added when her record has a left-arm baseline
MODULES = {  # tag -> questions added (the order here is the order they are asked)
    "dizziness_or_vision": ["Q_DIZZY", "Q_VISION"],
    "fever_chills": ["Q_CHILLS", "Q_FEELS_HOT"],
    "headache": ["Q_HEADACHE", "Q_HEAD_SCORE", "Q_HEAD_WORSE"],
    "nausea_vomiting": ["Q_NAUSEA", "Q_VOMIT", "Q_LIQUIDS", "Q_SUPP"],
    "sleepiness": ["Q_DROWSY"],
    "arm_pain": ["Q_ARM_SCORE", "Q_ARM_SUDDEN"],
    "arm_swelling_or_redness": ["Q_SWOLLEN", "Q_SKIN"],
    "tiredness": ["Q_TIRED_DAYS", "Q_TIRED_WORSE"],
    "chest_or_breathing": [],  # already in the core
    "other_symptom": [],  # no question can cover it: the router raises a floor so a nurse looks
}
FALLBACK = [  # the fixed 12, used when the tags cannot be trusted
    "Q_SLURRED", "Q_AWAKE", "Q_CHEST", "Q_ARM_RED", "Q_TEMP", "Q_VOMIT",
    "Q_HEADACHE", "Q_HEAD_SCORE", "Q_HEAD_WORSE", "Q_BANGLES", "Q_NAUSEA", "Q_SUPP",
]  # fmt: skip
FLOORS = {"SEVERE": "AMBER_PATIENT_SAYS_SEVERE", "OTHER": "AMBER_OTHER_SYMPTOM_REPORTED"}

STANDARD_REPLY = {
    "template_id": "TPL_WA_NOT_HEALTH_V1",
    "english": (
        "Thank you for your message. This number is only for health concerns after your treatment, so we "
        "have not acted on it. For anything else, please contact the hospital helpdesk. If you feel unwell "
        "in any way, send us a voice message or reply HELP."
    ),
    "tamil_draft": (
        "உங்கள் செய்திக்கு நன்றி. இந்த எண் சிகிச்சைக்குப் பிறகான உடல்நலக் கவலைகளுக்கு மட்டுமே. எனவே இதன் மீது "
        "நாங்கள் நடவடிக்கை எடுக்கவில்லை. மற்ற விஷயங்களுக்கு மருத்துவமனை உதவி மையத்தைத் தொடர்பு கொள்ளவும். "
        "உடல்நிலை சரியில்லை என்றால் எங்களுக்குக் குரல் செய்தி அனுப்பவும் அல்லது HELP என்று பதிலளிக்கவும்."
    ),
}  # fmt: skip


def clean_tags(raw):
    """Make the model's tags safe. Anything odd is replaced by the cautious reading."""
    ok = (
        isinstance(raw, dict)
        and raw.get("health_related") in HEALTH
        and isinstance(raw.get("symptoms"), list)
    )
    if not ok:
        return {"valid": False, "health_related": "UNSURE", "symptoms": [], "severity_word": "NONE"}
    seen = []
    for s in raw["symptoms"]:
        tag = (
            s if s in SYMPTOM_TAGS else "other_symptom"
        )  # a tag we do not know is a symptom we cannot ask about
        if tag not in seen:
            seen.append(tag)
    return {"valid": True, "health_related": raw["health_related"], "symptoms": seen,
            "severity_word": "SEVERE" if raw.get("severity_word") == "SEVERE" else "NONE"}  # fmt: skip


def route(raw_tags):
    """STANDARD_REPLY only when the message is clearly not about health. Everything else is triage."""
    t = clean_tags(raw_tags)
    if t["valid"] and t["health_related"] == "NO" and not t["symptoms"] and t["severity_word"] == "NONE":
        return {"route": "STANDARD_REPLY", "reason": "NOT_HEALTH", "tags": t, "reply": STANDARD_REPLY}
    return {"route": "TRIAGE", "reason": "TAGS_UNUSABLE" if not t["valid"] else "HEALTH_OR_UNSURE", "tags": t}


def select_questions(seed, raw_tags):
    """Returns the plan for the call: profile, ordered question ids, the fields that are active, floors."""
    r = route(raw_tags)
    if r["route"] == "STANDARD_REPLY":
        return {"route": "STANDARD_REPLY", "profile": None, "question_ids": [], "active_fields": set(), "floors": [],
                "modules": [], "tags": r["tags"], "reply": STANDARD_REPLY}  # fmt: skip
    t = r["tags"]
    if not t["valid"] or not t["symptoms"]:  # cannot tell what she said: ask the fixed 12
        ids, profile, modules = list(FALLBACK), "DEMO_LITE", ["fallback"]
        floors = [FLOORS["SEVERE"]] if t["severity_word"] == "SEVERE" else []
    else:
        ids = list(CORE)
        has_arm_baseline = bool(seed.get("longitudinal_baseline", {}).get("last_recorded_left_arm"))
        if has_arm_baseline:
            ids += HISTORY_ARM
        modules = ["core"] + (["history_arm"] if has_arm_baseline else [])
        for tag in MODULES:  # MODULES order, not the order she said them: danger-type modules come first
            if tag in t["symptoms"]:
                ids += [q for q in MODULES[tag] if q not in ids]
                modules.append(tag)
        profile = "ROUTED"
        floors = []
        if t["severity_word"] == "SEVERE":
            floors.append(FLOORS["SEVERE"])
        if "other_symptom" in t["symptoms"]:
            floors.append(FLOORS["OTHER"])
    fields = {f for q in ids for f in BY_ID[q]["fields"]}
    return {"route": "TRIAGE", "profile": profile, "question_ids": ids, "active_fields": fields,
            "floors": floors, "modules": modules, "tags": t}  # fmt: skip


def evaluate(seed, plan, payload):
    """Run the rule engine with the plan the router made for this call."""
    import triage

    return triage.triage(seed, payload, profile=plan["profile"], active=plan["active_fields"], floors=plan["floors"])
