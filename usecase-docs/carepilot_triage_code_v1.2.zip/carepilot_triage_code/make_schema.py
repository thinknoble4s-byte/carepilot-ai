"""Builds extraction_schema.json: the contract between the speech model and the rule engine."""

import json

TRI = {"enum": ["YES", "NO", "UNKNOWN", "NOT_ASKED"]}


def num(lo, hi):
    return {"type": ["number", "null"], "minimum": lo, "maximum": hi}


fields = {
    # ----- Red questions
    "slurred_or_confused": TRI,
    "blurred_vision": TRI,
    "unsteady_or_dizzy_walking": TRI,
    "cannot_stay_awake": TRI,
    "shaking_chills": TRI,
    "arm_red_or_hot": TRI,
    "chest_pain": TRI,
    "short_of_breath": TRI,
    # ----- Headache group
    "headache_present": TRI,
    "headache_score": num(1, 10),
    "headache_band": {"enum": ["MILD", "MEDIUM", "STRONG", None]},
    "headache_worst_on_waking": TRI,
    "headache_worse_than_last_time": TRI,
    "headache_hours": num(0, 720),
    # ----- Other questions
    "drowsy_most_of_today": TRI,
    "feels_hot": TRI,
    "thermometer_used": TRI,
    "temperature_value": num(0, 120),
    "nausea_since_yesterday": TRI,
    "nausea_now": TRI,
    "took_supplements_after_full_meals": TRI,
    "vomiting_count": num(0, 50),
    "can_keep_liquids_down": TRI,
    "skin_break_left_arm": TRI,
    "bangles_tighter": TRI,
    "arm_swollen": TRI,
    "arm_pain": TRI,
    # router-only questions (NOT_ASKED or null in the FULL profile)
    "arm_pain_score": num(1, 10),
    "arm_pain_sudden": TRI,
    "tired_days": num(0, 365),
    "tired_getting_worse": TRI,
}
schema = {
    "$schema": "https://json-schema.org/draft/2020-12/schema",
    "$id": "carepilot_triage_extraction_v1",
    "title": "CarePilot triage extraction (one call)",
    "type": "object",
    "required": ["call_metadata", "answers"],
    "additionalProperties": False,
    "properties": {
        "call_metadata": {
            "type": "object",
            "required": [
                "demo_clock_iso",
                "sender_role",
                "callback_answered",
                "callback_attempts",
                "transcript_usable",
                "nurse_key_pressed",
                "caregiver_consent",
                "stopped_after_danger_sign",
            ],
            "additionalProperties": False,
            "properties": {
                "demo_clock_iso": {"type": "string", "format": "date-time"},
                "sender_role": {"enum": ["PATIENT", "CAREGIVER", "UNKNOWN"]},
                "callback_answered": {"type": "boolean"},
                "callback_attempts": {"type": "integer", "minimum": 0, "maximum": 5},
                "transcript_usable": {"type": "boolean"},
                "nurse_key_pressed": {"type": "boolean"},
                "caregiver_consent": {"type": "boolean"},
                "stopped_after_danger_sign": {"type": "boolean"},
            },
        },
        "answers": {
            "type": "object",
            "required": [f for f in fields if f != "headache_band"],
            "additionalProperties": False,
            "properties": fields,
        },
    },
}
json.dump(schema, open("extraction_schema.json", "w"), indent=2)
print("fields:", len(fields))
