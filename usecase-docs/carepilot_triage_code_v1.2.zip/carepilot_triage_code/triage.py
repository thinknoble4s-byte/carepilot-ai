"""CarePilot Symptom Triage Protocol v1  (DRAFT, not yet signed by a clinician).

Plain Python. No AI, no network, no clock. Same input always gives the same output.
The model only turns speech into the answers dict. This file decides the tier.
"""

from datetime import datetime, date

PROTOCOL_ID = "Symptom_Triage_Protocol_v1"
PROTOCOL_STATUS = "DRAFT_UNSIGNED"  # change only after the sign-off table is filled

# ---- Thresholds: every number a clinician must sign. Change here, nowhere else. ----
CONFIG = {
    "fever_threshold_f": 100.4,  # measured temperature at or above this is Red
    "vomiting_amber_min": 2,  # 2 to 5 vomits in 24 h is Amber (safety bias)
    "vomiting_red_min": 6,  # 6 or more is Red
    "headache_red_score": 7,  # 7 out of 10 or more is Red
    "headache_rise_amber": 2,  # score 2 or more above the last recorded score is Amber
    "headache_hours_amber": 48,  # headache lasting 48 h or more is Amber
    "window_days": 14,  # look back this many days for repeat symptoms
    "recurrence_count": 3,  # this call counts as one of the three
    "symptom_guard_count": 3,  # 3 or more symptoms still present now is Amber (FULL profile only)
    "arm_pain_amber_score": 7,  # left arm pain of 7 out of 10 or more is Amber [SIGN-OFF]
    "tired_days_amber": 7,  # tiredness for 7 days or more is Amber [SIGN-OFF]
}

YES, NO, UNKNOWN, NOT_ASKED = "YES", "NO", "UNKNOWN", "NOT_ASKED"
SYMPTOMS = ("headache", "nausea", "drowsiness", "arm_pain")
BAND_TO_SCORE = {"MILD": 3, "MEDIUM": 6, "STRONG": 10}  # keypad fallback, uses the top of each band

# ---- Profiles: which questions the call actually asks. One engine, three sizes. ----
# FULL      all 26 original questions (the full guide).
# DEMO_LITE the fixed 12-question set. Used as the safe fallback when the message cannot be tagged.
# routed    any set of questions chosen by router.py from what the patient said. Passed as `active`.
# A field that is not asked is stored as NOT_ASKED and no rule can fire on it.
PROFILE_DEFAULT = "FULL"
LITE_FIELDS = {
    "slurred_or_confused", "cannot_stay_awake", "chest_pain", "arm_red_or_hot",
    "thermometer_used", "temperature_value",
    "vomiting_count",
    "headache_present", "headache_score", "headache_worse_than_last_time",
    "bangles_tighter",
    "nausea_since_yesterday", "took_supplements_after_full_meals",
}  # fmt: skip
PROFILES = {"FULL": None, "DEMO_LITE": LITE_FIELDS, "ROUTED": None}
# Four questions that only the router can ask. In the FULL profile they are never asked.
ROUTED_ONLY_FIELDS = {"arm_pain_score", "arm_pain_sudden", "tired_days", "tired_getting_worse"}

RED_YES_FIELDS = {  # answer YES means danger
    "slurred_or_confused": "RED_SLURRED_OR_CONFUSED",
    "blurred_vision": "RED_BLURRED_VISION",
    "unsteady_or_dizzy_walking": "RED_UNSTEADY_OR_DIZZY",
    "cannot_stay_awake": "RED_CANNOT_STAY_AWAKE",
    "shaking_chills": "RED_SHAKING_CHILLS",
    "arm_red_or_hot": "RED_ARM_RED_OR_HOT",
    "chest_pain": "RED_CHEST_PAIN",
    "short_of_breath": "RED_SHORT_OF_BREATH",
}
HEADACHE_CHILDREN = ("headache_worst_on_waking", "headache_worse_than_last_time")

ACTIONS = {  # key -> (action code, patient template, response time in minutes)
    "RED_CONFIRMED": ("ER_DESK_HANDOFF_SIMULATED", "TPL_CALL_RED_V1", 0),
    "RED_UNCONFIRMED": ("NURSE_CALLBACK_NOW", "TPL_CALL_RED_UNSURE_V1", 15),
    "RED_NO_ANSWER": ("ALERT_NURSE_AND_CALL_CAREGIVER", "TPL_CALL_CAREGIVER_V1", 0),
    "AMBER": ("DOCTOR_CALLBACK_2H", "TPL_CALL_AMBER_V1", 120),
    "AMBER_HUMAN_NOW": ("COORDINATOR_IMMEDIATE_CALLBACK", "TPL_CALL_NURSE_V1", 15),
    "AMBER_TODAY": ("COORDINATOR_CALL_TODAY", "TPL_WA_CALL_FAILED_V1", 240),
    "GREEN": ("GREEN_COACH_AND_FOLLOWUP_24H", "TPL_CALL_GREEN_V1", 1440),
}


# ------------------------------------------------------------------ helpers
def _yn(a, field):
    """Return YES or NO. Anything else (missing, None, junk) becomes UNKNOWN."""
    v = a.get(field)
    return v if v in (YES, NO) else UNKNOWN


def _child_yn(a, field, parent_is_no):
    """A follow-up question. If the parent answer was a clear NO it was never asked."""
    if parent_is_no:
        return NOT_ASKED
    return _yn(a, field)


def _number(a, field, lo, hi):
    v = a.get(field)
    ok = isinstance(v, (int, float)) and not isinstance(v, bool) and lo <= v <= hi
    return v if ok else None


def temperature_to_f(value):
    """Guess the unit from the number. 90 to 110 is Fahrenheit, 32 to 43 is Celsius."""
    if value is None:
        return None
    if 90 <= value <= 110:
        return float(value)
    if 32 <= value <= 43:
        return float(value) * 9.0 / 5.0 + 32.0
    return None


def fever_status(thermometer_used, temperature_value):
    """The model never decides 'fever'. This function does, from the number."""
    if thermometer_used == NO:
        return "UNMEASURED"
    if thermometer_used == YES:
        f = temperature_to_f(temperature_value)
        if f is None:
            return "UNKNOWN_READING"
        return (
            "MEASURED_FEBRILE"
            if round(f, 2) >= CONFIG["fever_threshold_f"]
            else "MEASURED_AFEBRILE"
        )
    return "UNKNOWN_READING"


def rolling_counts(events, today):
    """How many earlier events in the last N days had each symptom. Uses the demo clock date."""
    counts = {s: 0 for s in SYMPTOMS}
    for e in events:
        age = (today - date.fromisoformat(e["timestamp"][:10])).days
        if 0 <= age <= CONFIG["window_days"]:
            for s in SYMPTOMS:
                if e["symptoms_present"].get(s):
                    counts[s] += 1
    return counts


def normalise(raw, ended_early=False, active=None):
    """Turn whatever the extractor gave us into a clean, complete answers dict."""
    a = {}
    for f in list(RED_YES_FIELDS) + [
        "drowsy_most_of_today",
        "headache_present",
        "feels_hot",
        "thermometer_used",
        "nausea_since_yesterday",
        "skin_break_left_arm",
        "bangles_tighter",
        "arm_swollen",
        "arm_pain",
    ]:
        a[f] = _yn(raw, f)
    no_headache = a["headache_present"] == NO
    for f in HEADACHE_CHILDREN:
        a[f] = _child_yn(raw, f, no_headache)
    a["headache_score"] = NOT_ASKED if no_headache else _number(raw, "headache_score", 1, 10)
    a["headache_band"] = (
        raw.get("headache_band") if raw.get("headache_band") in BAND_TO_SCORE else None
    )
    a["headache_hours"] = NOT_ASKED if no_headache else _number(raw, "headache_hours", 0, 720)
    no_nausea = a["nausea_since_yesterday"] == NO
    a["nausea_now"] = _child_yn(raw, "nausea_now", no_nausea)
    a["took_supplements_after_full_meals"] = _child_yn(
        raw, "took_supplements_after_full_meals", no_nausea
    )
    a["vomiting_count"] = _number(raw, "vomiting_count", 0, 50)
    clear_stomach = no_nausea and a["vomiting_count"] == 0
    a["can_keep_liquids_down"] = _child_yn(raw, "can_keep_liquids_down", clear_stomach)
    a["temperature_value"] = (
        NOT_ASKED if a["thermometer_used"] == NO else _number(raw, "temperature_value", 0, 120)
    )
    a["arm_pain_score"] = _number(raw, "arm_pain_score", 1, 10)
    a["arm_pain_sudden"] = _yn(raw, "arm_pain_sudden")
    a["tired_days"] = _number(raw, "tired_days", 0, 365)
    a["tired_getting_worse"] = _yn(raw, "tired_getting_worse")
    if (
        ended_early
    ):  # call cut short (nurse key): questions never reached are NOT_ASKED, not UNKNOWN
        for f, v in list(a.items()):
            if v == UNKNOWN and raw.get(f) in (None, NOT_ASKED):
                a[f] = NOT_ASKED
    if active is None:  # FULL: the four router-only questions are never asked
        active = (set(a) | {"headache_band"}) - ROUTED_ONLY_FIELDS
    for f in list(a):  # anything not asked is NOT_ASKED, whatever the extractor sent
        if f not in active and f != "headache_band":
            a[f] = NOT_ASKED
    return a


def pick_instruction(seed, a):
    """Replay only a doctor's signed, repeatable instruction, and only if it fits a symptom reported today."""
    present = {
        "nausea": a["nausea_since_yesterday"] == YES,
        "headache": a["headache_present"] == YES,
        "drowsiness": a["drowsy_most_of_today"] == YES,
        "arm_pain": a["arm_pain"] == YES,
    }
    for ins in seed.get("clinician_repeatable_instructions", []):
        if (
            ins.get("patient_repeatable") is True
            and ins.get("signed_by")
            and present.get(ins.get("applies_to_symptom"))
        ):
            return ins["instruction_id"]
    return None


def _result(tier, reasons, action_key, inputs, confirmed=False, instruction=None):
    action, template, minutes = ACTIONS[action_key]
    return {
        "protocol_id": PROTOCOL_ID,
        "protocol_status": PROTOCOL_STATUS,
        "protocol_profile": PROFILE_DEFAULT,
        "tier": tier,
        "reason_codes": sorted(set(reasons)),
        "confirmed_danger": confirmed,
        "action_code": action,
        "patient_template_id": template,
        "response_minutes": minutes,
        "repeat_instruction_id": instruction,
        "decision_inputs": inputs,
    }


# ------------------------------------------------------------------ the protocol
def triage(seed, payload, profile=PROFILE_DEFAULT, active=None, floors=()):
    """Public entry point.

    profile "FULL" asks everything; "DEMO_LITE" asks the fixed 12; "ROUTED" asks the fields in `active`.
    floors are reason codes the router sets (for example the patient called it "severe"): they can
    only raise a Green to Amber, never lower anything.
    """
    if profile == "ROUTED" and not active:
        return {**_result("TIER_1_RED", ["RED_SYSTEM_FAULT"], "RED_UNCONFIRMED", {"error": "no active fields"}),
                "protocol_profile": profile}  # fmt: skip
    if profile in PROFILES and PROFILES[profile] is not None:
        active = PROFILES[profile]
    result = _triage_inner(
        seed, payload, profile, frozenset(active) if active else None, tuple(floors)
    )
    result["protocol_profile"] = profile
    return result


def _triage_inner(seed, payload, profile, active, floors):
    """payload = {"call_metadata": {...}, "answers": {...}}.  Returns the tier and why."""
    try:
        meta, raw = payload["call_metadata"], payload["answers"]
        today = datetime.fromisoformat(meta["demo_clock_iso"]).date()
        if not isinstance(raw, dict) or not isinstance(meta, dict):
            raise ValueError("bad shape")
    except (KeyError, TypeError, ValueError):
        return _result(
            "TIER_1_RED", ["RED_SYSTEM_FAULT"], "RED_UNCONFIRMED", {"error": "unreadable payload"}
        )

    # 1. Call-level checks (before any clinical answer is read)
    if meta.get("callback_answered") is False:
        if meta.get("callback_attempts", 0) >= 2:
            return _result(
                "TIER_1_RED",
                ["RED_NO_ANSWER_2X"],
                "RED_NO_ANSWER",
                {"attempts": meta.get("callback_attempts")},
            )
        return {
            "tier": "RETRY_CALL",
            "reason_codes": [],
            "decision_inputs": {"attempts": meta.get("callback_attempts", 0)},
        }
    role = meta.get("sender_role")
    if role not in ("PATIENT", "CAREGIVER"):
        return _result(
            "TIER_2_AMBER", ["AMBER_ROLE_NOT_CONFIRMED"], "AMBER_HUMAN_NOW", {"sender_role": role}
        )
    if role == "CAREGIVER" and meta.get("caregiver_consent") is not True:
        return _result(
            "TIER_2_AMBER", ["AMBER_CAREGIVER_NO_CONSENT"], "AMBER_HUMAN_NOW", {"sender_role": role}
        )

    ended_early = (
        meta.get("nurse_key_pressed") is True
        or meta.get("transcript_usable") is False
        or meta.get("stopped_after_danger_sign") is True
    )
    if profile not in PROFILES:
        return _result(
            "TIER_1_RED", ["RED_SYSTEM_FAULT"], "RED_UNCONFIRMED", {"error": "unknown profile"}
        )
    a = normalise(raw, ended_early, active)
    fever = fever_status(
        a["thermometer_used"],
        a["temperature_value"] if isinstance(a["temperature_value"], (int, float)) else None,
    )
    score = (
        a["headache_score"]
        if isinstance(a["headache_score"], (int, float))
        else BAND_TO_SCORE.get(a["headache_band"])
    )
    counts = rolling_counts(seed.get("events", []), today)
    inputs = {
        "sender_role": role,
        "answers": a,
        "fever_status": fever,
        "headache_score_used": score,
        "rolling_counts": counts,
    }

    # 2. RED: any danger answer, or any danger question we could not confirm
    red, unconfirmed, confirmed = [], [], False
    for f, code in RED_YES_FIELDS.items():
        if a[f] == YES:
            red.append(code)
            confirmed = True
        elif a[f] == UNKNOWN:
            unconfirmed.append(f)
    if a["headache_present"] not in (NO, NOT_ASKED):  # only if the headache questions were asked
        if a["headache_worst_on_waking"] == YES:
            red.append("RED_HEADACHE_WORST_ON_WAKING")
            confirmed = True
        elif a["headache_worst_on_waking"] == UNKNOWN:
            unconfirmed.append("headache_worst_on_waking")
        if score is None:
            unconfirmed.append("headache_score")
        elif score >= CONFIG["headache_red_score"]:
            red.append("RED_HEADACHE_SEVERE_7_PLUS")
            confirmed = True
    if a["vomiting_count"] == NOT_ASKED:
        pass  # the vomiting question was not part of this call
    elif a["vomiting_count"] is None:
        unconfirmed.append("vomiting_count")
    elif a["vomiting_count"] >= CONFIG["vomiting_red_min"]:
        red.append("RED_VOMITING_6_PLUS")
        confirmed = True
    if a["can_keep_liquids_down"] == NO:
        red.append("RED_CANNOT_KEEP_LIQUIDS")
        confirmed = True
    elif a["can_keep_liquids_down"] == UNKNOWN:
        unconfirmed.append("can_keep_liquids_down")
    if fever == "MEASURED_FEBRILE":
        red.append("RED_FEVER_100_4F_PLUS")
        confirmed = True
    if unconfirmed and not ended_early:
        red.append("RED_CANNOT_CONFIRM_SAFE")
        inputs["unconfirmed_fields"] = unconfirmed
    if red:
        return _result(
            "TIER_1_RED",
            red,
            "RED_CONFIRMED" if confirmed else "RED_UNCONFIRMED",
            inputs,
            confirmed,
        )
    if (
        meta.get("stopped_after_danger_sign") is True
    ):  # the call pane says it saw a danger sign, the answers do not
        return _result("TIER_1_RED", ["RED_SYSTEM_FAULT"], "RED_UNCONFIRMED", inputs)

    # 3. AMBER
    amber, unknown_amber = [], []
    amber_yn = [
        "drowsy_most_of_today",
        "headache_present",
        "feels_hot",
        "nausea_since_yesterday",
        "skin_break_left_arm",
        "bangles_tighter",
        "arm_swollen",
        "arm_pain",
        "headache_worse_than_last_time",
        "nausea_now",
        "took_supplements_after_full_meals",
        "arm_pain_sudden",
        "tired_getting_worse",
    ]
    unknown_amber = [f for f in amber_yn if a[f] == UNKNOWN]
    for f in ("arm_pain_score", "tired_days"):  # numbers that were asked but could not be read
        if a[f] is None:
            unknown_amber.append(f)
    if a["headache_hours"] is None:
        unknown_amber.append("headache_hours")
    if fever == "UNKNOWN_READING":
        unknown_amber.append("thermometer_or_temperature")
    if unknown_amber and not ended_early:
        amber.append("AMBER_CANNOT_CONFIRM")
        inputs["unconfirmed_fields"] = unknown_amber

    if a["drowsy_most_of_today"] == YES:
        amber.append("AMBER_DROWSY_MOST_OF_TODAY")
    if a["headache_worse_than_last_time"] == YES:
        amber.append("AMBER_HEADACHE_WORSE_THAN_LAST_TIME")
    last = (
        seed.get("longitudinal_baseline", {})
        .get("last_recorded_headache", {})
        .get("pain_score_1_to_10")
    )
    if (
        score is not None
        and last is not None
        and a["headache_present"] != NO
        and score >= last + CONFIG["headache_rise_amber"]
    ):
        amber.append("AMBER_HEADACHE_RISE_2_PLUS")
    if (
        isinstance(a["headache_hours"], (int, float))
        and a["headache_hours"] >= CONFIG["headache_hours_amber"]
    ):
        amber.append("AMBER_HEADACHE_48H_PLUS")
    vc = a["vomiting_count"] if isinstance(a["vomiting_count"], (int, float)) else None
    if vc is not None and CONFIG["vomiting_amber_min"] <= vc < CONFIG["vomiting_red_min"]:
        amber.append("AMBER_VOMITING_2_TO_5")
    nausea_for_rule = (
        a["nausea_now"] if a["nausea_now"] != NOT_ASKED else a["nausea_since_yesterday"]
    )
    if nausea_for_rule == YES and a["took_supplements_after_full_meals"] == YES:
        amber.append("AMBER_NAUSEA_DESPITE_MEALS")
    if a["bangles_tighter"] == YES:
        amber.append("AMBER_BANGLES_TIGHTER_THAN_BASELINE")
    if a["arm_swollen"] == YES:
        amber.append("AMBER_ARM_SWOLLEN")
    if a["skin_break_left_arm"] == YES:
        amber.append("AMBER_SKIN_BREAK_LEFT_ARM")
    if fever == "UNMEASURED":
        if a["feels_hot"] == YES:
            amber.append("AMBER_FEELS_HOT_NO_THERMOMETER")
        elif (
            a["headache_present"] == YES
            or a["nausea_since_yesterday"] == YES
            or a["drowsy_most_of_today"] == YES
            or (vc or 0) >= 1
        ):
            amber.append("AMBER_NO_THERMOMETER_WITH_SYMPTOMS")

    if (
        isinstance(a["arm_pain_score"], (int, float))
        and a["arm_pain_score"] >= CONFIG["arm_pain_amber_score"]
    ):
        amber.append("AMBER_ARM_PAIN_7_PLUS")
    if a["arm_pain_sudden"] == YES:
        amber.append("AMBER_ARM_PAIN_SUDDEN_ONSET")
    if isinstance(a["tired_days"], (int, float)) and a["tired_days"] >= CONFIG["tired_days_amber"]:
        amber.append("AMBER_TIREDNESS_7_DAYS_PLUS")
    if a["tired_getting_worse"] == YES:
        amber.append("AMBER_TIREDNESS_GETTING_WORSE")
    amber.extend(
        floors
    )  # set by the router from the patient's own message (e.g. she says "severe")

    today_present = {
        "headache": a["headache_present"] == YES,
        "nausea": a["nausea_since_yesterday"] == YES,
        "drowsiness": a["drowsy_most_of_today"] == YES,
        "arm_pain": a["arm_pain"] == YES or isinstance(a["arm_pain_score"], (int, float)),
    }
    for s in SYMPTOMS:
        if today_present[s] and counts[s] + 1 >= CONFIG["recurrence_count"]:
            amber.append("AMBER_RECURRING_3X_14D_" + s.upper())
    now_present = [
        a["headache_present"] == YES,
        a["nausea_now"] == YES,
        a["drowsy_most_of_today"] == YES,
        a["arm_pain"] == YES,
    ]
    if profile == "FULL" and sum(now_present) >= CONFIG["symptom_guard_count"]:
        amber.append("AMBER_THREE_OR_MORE_SYMPTOMS_NOW")

    if meta.get("nurse_key_pressed") is True:
        amber.append("AMBER_NURSE_REQUESTED")
    if meta.get("transcript_usable") is False:
        amber.append("AMBER_TRANSCRIPT_UNUSABLE")
    if amber:
        only_other = set(amber) <= {"AMBER_OTHER_SYMPTOM_REPORTED"}  # a complaint no question covers: a nurse calls
        return _result(
            "TIER_2_AMBER", amber, "AMBER_HUMAN_NOW" if ended_early or only_other else "AMBER", inputs
        )

    # 4. GREEN: only when nothing above fired and nothing was left unconfirmed
    explicit_green_gate = not unconfirmed and not unknown_amber and not ended_early
    if not explicit_green_gate:
        return _result("TIER_2_AMBER", ["AMBER_CANNOT_CONFIRM"], "AMBER_HUMAN_NOW", inputs)
    inputs["facts"] = [f"{k}={v}" for k, v in a.items() if v not in (NO, NOT_ASKED, None)] + [
        f"fever_status={fever}"
    ]
    return _result("TIER_3_GREEN", [], "GREEN", inputs, instruction=pick_instruction(seed, a))


def facts_text(result):
    """One plain sentence of what the patient reported, built only from stored answers (no AI wording)."""
    i = result["decision_inputs"]
    if "answers" not in i:
        return "No answers recorded."
    a, out = i["answers"], []
    fmt = lambda v: str(int(v)) if float(v).is_integer() else str(v)
    if a["headache_present"] == YES:
        t = (
            f"Headache {fmt(i['headache_score_used'])}/10"
            if i.get("headache_score_used") is not None
            else "Headache"
        )
        if isinstance(a["headache_hours"], (int, float)):
            t += f" for {fmt(a['headache_hours'])} h"
        out.append(t)
    if a["nausea_since_yesterday"] == YES:
        now = {YES: ", still present", NO: ", settled"}.get(
            a["nausea_now"], ""
        )  # not asked: say nothing
        out.append("Nausea since yesterday" + now)
    if isinstance(a["vomiting_count"], (int, float)):
        out.append(f"Vomited {fmt(a['vomiting_count'])} time(s)")
    if isinstance(a["arm_pain_score"], (int, float)):
        out.append(f"Left arm pain {fmt(a['arm_pain_score'])}/10")
    if a["arm_pain_sudden"] == YES:
        out.append("Arm pain started suddenly")
    if isinstance(a["tired_days"], (int, float)):
        out.append(f"Tired for {fmt(a['tired_days'])} day(s)")
    if a["tired_getting_worse"] == YES:
        out.append("Tiredness getting worse")
    flags = {
        "drowsy_most_of_today": "Sleepy most of today",
        "bangles_tighter": "Bangles tighter than before",
        "arm_swollen": "Left arm swollen",
        "arm_pain": "Left arm pain",
        "feels_hot": "Feels hot",
        "shaking_chills": "Shaking chills",
        "skin_break_left_arm": "Cut or bite on left arm",
        "arm_red_or_hot": "Left arm red or hot",
        "slurred_or_confused": "Slurred speech or confusion",
        "cannot_stay_awake": "Very hard to stay awake",
        "chest_pain": "Chest pain or trouble breathing",
    }
    out += [text for f, text in flags.items() if a.get(f) == YES]
    if isinstance(a["temperature_value"], (int, float)):
        out.append("Thermometer " + fmt(a["temperature_value"]))
    elif a["thermometer_used"] == NO:
        out.append("No thermometer at home")
    return "; ".join(out) + "."


# ------------------------------------------------------------------ the 24-hour follow-up call
def evaluate_followup(case, answers, attempts):
    """case is 'GREEN' or 'AMBER'. answers = {'feeling': BETTER|SAME|WORSE|UNKNOWN, 'anything_new': YES|NO|UNKNOWN} or None."""
    if answers is None:
        if attempts < 2:
            return {"status": "RETRY_CALL"}
        return _result(
            "TIER_2_AMBER", ["AMBER_NO_ANSWER_ON_FOLLOWUP"], "AMBER_TODAY", {"attempts": attempts}
        )
    if answers.get("feeling") == "BETTER" and answers.get("anything_new") == NO:
        return {
            "tier": "TIER_3_GREEN",
            "action_code": (
                "CLOSED_BY_AGENT_IN_DIGEST" if case == "GREEN" else "CLOSURE_PROPOSAL_FOR_HUMAN"
            ),
            "reason_codes": [],
            "needs_human_close": case == "AMBER",
        }
    code = "AMBER_NOT_BETTER_AFTER_24H" if case == "GREEN" else "AMBER_REOPENED_NOT_BETTER"
    return _result("TIER_2_AMBER", [code], "AMBER", {"followup": answers})


# ------------------------------------------------------------------ the Pre-OPD brief (a template, no AI)
def render_brief(patient, events, as_of):
    """Facts only. Every line comes from a stored field and carries its source id."""
    n = {"TIER_1_RED": 0, "TIER_2_AMBER": 0, "TIER_3_GREEN": 0}
    for e in events:
        n[e["tier"]] += 1
    out = [
        f"CAREPILOT 90-DAY PRE-OPD BRIEF (facts only, no AI interpretation)   {patient['data_label']}",
        f"Patient: {patient['name']} ({patient['age']}{patient['sex']})  ID: {patient['patient_id']}   As of: {as_of}",
        f"Episodes: {n['TIER_1_RED']} Red | {n['TIER_2_AMBER']} Amber | {n['TIER_3_GREEN']} Green",
        "",
    ]
    for e in sorted(events, key=lambda x: x["timestamp"]):
        out.append(
            f"{e['timestamp'][:10]}  {e['event_id']}  {e['tier']} ({e.get('tier_source', 'PROTOCOL_V1')})"
        )
        if e.get("reason_codes"):
            out.append("   Rules fired: " + ", ".join(e["reason_codes"]))
        out.append("   Patient said: " + e["patient_reported_facts"])
        if e.get("instruction_copied"):
            out.append("   Doctor instruction (copied): " + e["instruction_copied"])
        out.append("   Outcome (recorded by " + e["closed_by"] + "): " + e["outcome_recorded"])
        out.append("   Source: " + e["audio_uri"])
    return "\n".join(out)
