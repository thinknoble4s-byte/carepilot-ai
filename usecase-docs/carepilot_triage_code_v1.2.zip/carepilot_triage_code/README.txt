CarePilot Symptom Triage Protocol v1.2 - code for the MVP-lite guide (SYNTHETIC DATA ONLY)

Files
  triage.py               the rules (no AI, no clock, no network). profile = FULL, DEMO_LITE or ROUTED
  router.py               reads the AI's tags, decides standard reply vs triage call, builds the question list
  questions.py            the 23-question bank (English, Tamil DRAFT, kind, history flag)
  triage_room.py          ticket, ticket ID, next action per role, states, tier changes, one-wav stitching
  red_package.py          Red package: family message, one-page PDF summary, doctor note, coordinator task
  why_panel.py            the "Why this tier" lines
  seed.json               the synthetic patient (history, care plan, signed instruction, signed note)
  extraction_schema.json  what the speech step must return (31 fields)
  scenarios.py            ready-made calls for QA (full, lite and routed)
  make_schema.py          rebuilds extraction_schema.json
  tests/                  189 automated tests

Run
  pip install pytest jsonschema reportlab pypdf
  pytest -q            (from this folder)

Status: the protocol is DRAFT_UNSIGNED until a clinician fills the sign-off table. Every phone number,
hospital number, name and Tamil line in the data is a placeholder, synthetic or an unverified draft.
