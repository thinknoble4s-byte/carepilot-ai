"""Ready-made calls for QA. Each is the exact input to triage(seed, payload)."""

import copy

META = {
    "demo_clock_iso": "2026-10-27T10:15:00+05:30",
    "sender_role": "PATIENT",
    "callback_answered": True,
    "callback_attempts": 1,
    "transcript_usable": True,
    "nurse_key_pressed": False,
    "caregiver_consent": True,
    "stopped_after_danger_sign": False,
}

# Scenario 3: the GREEN call. Every other scenario starts from this and changes a few answers.
GREEN_ANSWERS = {
    "slurred_or_confused": "NO",
    "blurred_vision": "NO",
    "unsteady_or_dizzy_walking": "NO",
    "cannot_stay_awake": "NO",
    "drowsy_most_of_today": "NO",
    "headache_present": "YES",
    "headache_score": 2,
    "headache_band": None,
    "headache_worst_on_waking": "NO",
    "headache_worse_than_last_time": "NO",
    "headache_hours": 3,
    "feels_hot": "NO",
    "shaking_chills": "NO",
    "thermometer_used": "YES",
    "temperature_value": 98.4,
    "nausea_since_yesterday": "YES",
    "nausea_now": "NO",
    "took_supplements_after_full_meals": "NO",
    "vomiting_count": 0,
    "can_keep_liquids_down": "YES",
    "skin_break_left_arm": "NO",
    "arm_red_or_hot": "NO",
    "bangles_tighter": "NO",
    "arm_swollen": "NO",
    "arm_pain": "YES",
    "chest_pain": "NO",
    "short_of_breath": "NO",
    "arm_pain_score": None,
    "arm_pain_sudden": "NOT_ASKED",
    "tired_days": None,
    "tired_getting_worse": "NOT_ASKED",
}


def make(answers=None, meta=None, **changes):
    a = copy.deepcopy(GREEN_ANSWERS)
    a.update(answers or {})
    a.update(changes)
    m = copy.deepcopy(META)
    m.update(meta or {})
    return {"call_metadata": m, "answers": a}


GREEN = make()

# Scenario 2: AMBER. Patient answers herself. No danger sign. Arm changed, headache worse, nausea despite meals.
AMBER = make(
    drowsy_most_of_today="YES",
    headache_score=5,
    headache_worse_than_last_time="YES",
    headache_hours=48,
    nausea_now="YES",
    took_supplements_after_full_meals="YES",
    bangles_tighter="YES",
    arm_swollen="YES",
)

# Scenario 1A: RED. The son answers. The very first clinical answer is a danger sign, so the call stops there.
# Questions after the first danger sign are never asked, so they are NOT_ASKED (numbers are null).
_NOT_ASKED = {k: ("NOT_ASKED" if isinstance(v, str) else None) for k, v in GREEN_ANSWERS.items()}
_NOT_ASKED["headache_band"] = None
RED_A = make(
    _NOT_ASKED,
    meta={"sender_role": "CAREGIVER", "stopped_after_danger_sign": True},
    slurred_or_confused="YES",
)

# Scenario 1B: RED by arm infection signs. The first six answers are NO, the seventh (arm red or hot) is YES, so the call stops.
_stop_b = dict(_NOT_ASKED)
_stop_b.update(
    slurred_or_confused="NO",
    blurred_vision="NO",
    unsteady_or_dizzy_walking="NO",
    cannot_stay_awake="NO",
    chest_pain="NO",
    short_of_breath="NO",
    arm_red_or_hot="YES",
)
RED_B = make(_stop_b, meta={"stopped_after_danger_sign": True})

# A call where several danger answers arrive at once. Used only by tests (the engine must cope with many Red reasons).
RED_MULTI = make(
    skin_break_left_arm="YES",
    arm_red_or_hot="YES",
    shaking_chills="YES",
    thermometer_used="YES",
    temperature_value=101.2,
)


# ---------------------------------------------------------------- DEMO_LITE fixtures (the fixed 12)
_NOT_ASKED_ALL = {k: ("NOT_ASKED" if isinstance(v, str) else None) for k, v in GREEN_ANSWERS.items()}
_LITE_CLEAR = dict(
    slurred_or_confused="NO", cannot_stay_awake="NO", chest_pain="NO", arm_red_or_hot="NO",
    thermometer_used="YES", temperature_value=98.4, vomiting_count=0,
    headache_present="YES", headache_score=2, headache_worse_than_last_time="NO",
    bangles_tighter="NO", nausea_since_yesterday="YES", took_supplements_after_full_meals="NO",
)  # fmt: skip
LITE_BASE_ANSWERS = {**_NOT_ASKED_ALL, **_LITE_CLEAR}


def make_lite(answers=None, meta=None, **changes):
    a = copy.deepcopy(LITE_BASE_ANSWERS)
    a.update(answers or {})
    a.update(changes)
    m = copy.deepcopy(META)
    m.update(meta or {})
    return {"call_metadata": m, "answers": a}


LITE_GREEN = make_lite()
LITE_AMBER = make_lite(headache_score=5, headache_worse_than_last_time="YES", bangles_tighter="YES",
                       took_supplements_after_full_meals="YES")  # fmt: skip
# The call stops at the first danger answer; later questions are NOT_ASKED.
_AFTER_ARM = ("thermometer_used", "temperature_value", "vomiting_count", "headache_present", "headache_score",
              "headache_worse_than_last_time", "bangles_tighter", "nausea_since_yesterday",
              "took_supplements_after_full_meals")  # fmt: skip
LITE_RED = make_lite({k: _NOT_ASKED_ALL[k] for k in _AFTER_ARM}, meta={"stopped_after_danger_sign": True},
                     arm_red_or_hot="YES")  # fmt: skip
LITE_NO_ANSWER = make_lite(meta={"callback_answered": False, "callback_attempts": 2})
VOICE_NOTE_TRANSLATION = (
    "Hello sister, this is Lakshmi speaking. Since yesterday I have been feeling very sleepy, "
    "and I have nausea, a headache, and pain in my left arm."
)

# ---------------------------------------------------------------- ROUTED fixtures (questions chosen from the message)
import json as _json
import os as _os

import router as _router

_SEED = _json.load(open(_os.path.join(_os.path.dirname(__file__), "seed.json")))
CLEAR = dict(  # a calm answer to every question in the bank
    slurred_or_confused="NO", cannot_stay_awake="NO", chest_pain="NO", arm_red_or_hot="NO",
    thermometer_used="YES", temperature_value=98.4, bangles_tighter="NO",
    unsteady_or_dizzy_walking="NO", blurred_vision="NO", shaking_chills="NO", feels_hot="NO",
    headache_present="YES", headache_score=2, headache_worse_than_last_time="NO",
    nausea_since_yesterday="YES", vomiting_count=0, can_keep_liquids_down="YES",
    took_supplements_after_full_meals="NO", drowsy_most_of_today="NO",
    arm_pain_score=2, arm_pain_sudden="NO", arm_swollen="NO", skin_break_left_arm="NO",
    tired_days=2, tired_getting_worse="NO",
)  # fmt: skip

TAGS_HERO = {"health_related": "YES", "symptoms": ["sleepiness", "nausea_vomiting", "headache", "arm_pain"],
             "severity_word": "NONE"}  # fmt: skip
TAGS_SEVERE_ARM = {"health_related": "YES", "symptoms": ["arm_pain"], "severity_word": "SEVERE"}
TAGS_TIRED = {"health_related": "YES", "symptoms": ["tiredness"], "severity_word": "NONE"}
TAGS_SHOPPING = {"health_related": "NO", "symptoms": [], "severity_word": "NONE"}
TAGS_RASH = {"health_related": "YES", "symptoms": ["skin_rash"], "severity_word": "NONE"}  # not in the list
TAGS_BROKEN = "the model returned text, not tags"


def make_routed(tags, meta=None, stop_at=None, **changes):
    """Returns (plan, payload). Active fields get a calm answer; everything else is NOT_ASKED."""
    plan = _router.select_questions(_SEED, tags)
    a = dict(_NOT_ASKED_ALL)
    active = plan["active_fields"]
    a.update({k: v for k, v in CLEAR.items() if k in active})
    a.update(changes)
    m = copy.deepcopy(META)
    m.update(meta or {})
    if stop_at:  # the call stopped at this question: later questions are NOT_ASKED
        later = False
        for qid in plan["question_ids"]:
            if later:
                for f in _router.BY_ID[qid]["fields"]:
                    a[f] = _NOT_ASKED_ALL[f]
            if qid == stop_at:
                later = True
        m["stopped_after_danger_sign"] = True
    return plan, {"call_metadata": m, "answers": a}


ROUTED_GREEN = make_routed(TAGS_HERO)
ROUTED_AMBER = make_routed(TAGS_HERO, drowsy_most_of_today="YES", headache_score=5, headache_worse_than_last_time="YES",
                           took_supplements_after_full_meals="YES", bangles_tighter="YES", arm_pain_score=5)  # fmt: skip
ROUTED_RED = make_routed(TAGS_HERO, stop_at="Q_ARM_RED", arm_red_or_hot="YES")
ROUTED_SEVERE_ARM = make_routed(
    TAGS_SEVERE_ARM, arm_pain_score=3
)  # her answers are mild; her own word is "severe"
ROUTED_TIRED = make_routed(TAGS_TIRED)
ROUTED_RASH = make_routed(TAGS_RASH)
