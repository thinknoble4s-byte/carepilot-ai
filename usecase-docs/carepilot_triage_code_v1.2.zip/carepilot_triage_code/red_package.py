"""The Red package: what goes out the moment a case is Red.

1. a fixed WhatsApp message to the caregiver, with a PDF summary attached
2. a facts-only note to the doctor
3. a task for the coordinator
Every line is a template or a stored fact. No sentence is written by a model.
"""

from reportlab.lib import colors
from reportlab.lib.pagesizes import A4
from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
from reportlab.lib.units import cm
from reportlab.platypus import Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

import triage

PACKAGE_CONFIG = {
    "auto_send_kinds": ("CONFIRMED", "NO_ANSWER"),  # UNCONFIRMED: a nurse calls first [SIGN-OFF]
    "coordinator_call_within_minutes": 30,  # [SIGN-OFF]
}

# Plain-English meaning of every Red reason code (used in the PDF and the notes)
REASON_PLAIN = {
    "RED_SLURRED_OR_CONFUSED": "Speech reported as slurred, or confusion",
    "RED_BLURRED_VISION": "Blurred vision reported",
    "RED_UNSTEADY_OR_DIZZY": "Dizziness or unsteadiness when walking reported",
    "RED_CANNOT_STAY_AWAKE": "Reported that it is very hard to stay awake",
    "RED_HEADACHE_WORST_ON_WAKING": "Headache reported as worst on waking in the morning",
    "RED_HEADACHE_SEVERE_7_PLUS": "Headache reported as 7 out of 10 or more",
    "RED_SHAKING_CHILLS": "Shaking chills reported",
    "RED_FEVER_100_4F_PLUS": "Temperature reported as 100.4 F (38.0 C) or more",
    "RED_VOMITING_6_PLUS": "Vomiting reported 6 or more times since yesterday",
    "RED_CANNOT_KEEP_LIQUIDS": "Reported that she cannot keep water down",
    "RED_ARM_RED_OR_HOT": "Left arm reported as red or hot to touch",
    "RED_CHEST_PAIN": "Chest pain reported",
    "RED_SHORT_OF_BREATH": "Shortness of breath reported",
    "RED_CANNOT_CONFIRM_SAFE": "Some answers could not be confirmed as safe",
    "RED_NO_ANSWER_2X": "She reported feeling unwell, then two calls were not answered",
    "RED_SYSTEM_FAULT": "The system could not read the answers",
}
ARM_PLAIN = {"NO_SWELLING_LOOSE_BANGLES": "no swelling, bangles loose"}

# One approved WhatsApp template. {REASON} is one of three fixed lines.
REASON_LINES = {
    "CONFIRMED": {
        "en": "{NAME} gave answers to our call that are warning signs.",
        "ta": "{NAME} அம்மா எங்கள் அழைப்பில் கொடுத்த பதில்கள் எச்சரிக்கை அறிகுறிகளைக் காட்டுகின்றன.",
    },
    "NO_ANSWER": {
        "en": "{NAME} sent us a message saying she is unwell. We called twice and could not reach her.",
        "ta": "{NAME} அம்மா தனக்கு உடல்நிலை சரியில்லை என்று எங்களுக்குச் செய்தி அனுப்பினார். இரண்டு முறை அழைத்தும் அவரைத் தொடர்பு கொள்ள முடியவில்லை.",
    },
    "UNCONFIRMED": {
        "en": "{NAME}'s answers could not be confirmed as safe.",
        "ta": "{NAME} அம்மாவின் பதில்கள் அவர் பாதுகாப்பாக இருக்கிறார் என்பதை உறுதிப்படுத்த முடியவில்லை.",
    },
}
TEMPLATE_ID = "TPL_WA_RED_CAREGIVER_V1"
TEMPLATE_EN = (
    "This is CarePilot's automated assistant. {REASON} Please take her to the nearest emergency "
    "department now. Do not wait. Show the attached summary to the emergency doctor. Our care "
    "team has been told and will call you."
)
TEMPLATE_TA = (
    "இது கேர்பைலட்டின் தானியங்கி உதவியாளர். {REASON} உடனே அவரை அருகிலுள்ள அவசர சிகிச்சைப் "
    "பிரிவுக்கு அழைத்துச் செல்லுங்கள். காத்திருக்க வேண்டாம். இணைக்கப்பட்ட சுருக்கத்தை அவசர "
    "சிகிச்சை மருத்துவரிடம் காட்டுங்கள். எங்கள் பராமரிப்புக் குழுவுக்குத் தெரிவிக்கப்பட்டுள்ளது; "
    "அவர்கள் உங்களை அழைப்பார்கள்."
)


def red_kind(result):
    """CONFIRMED (a danger answer), NO_ANSWER (2 missed calls) or UNCONFIRMED (could not confirm)."""
    if "RED_NO_ANSWER_2X" in result["reason_codes"]:
        return "NO_ANSWER"
    return "CONFIRMED" if result.get("confirmed_danger") else "UNCONFIRMED"


def first_name(patient):
    return patient["name"].replace("Mrs. ", "").split()[0]  # "Lakshmi"


def caregiver_message(seed, result):
    kind, name = red_kind(result), first_name(seed["patient_profile"])
    line = REASON_LINES[kind]
    return {
        "template_id": TEMPLATE_ID,
        "to": seed["patient_profile"]["caregiver_phone"],
        "kind": kind,
        "english": TEMPLATE_EN.replace("{REASON}", line["en"].replace("{NAME}", name + " Amma")),
        "tamil_draft": TEMPLATE_TA.replace("{REASON}", line["ta"].replace("{NAME}", name)),
        "attachment": "emergency_summary.pdf",
    }


def doctor_note(seed, result, sent_at):
    p, kind = seed["patient_profile"], red_kind(result)
    why = "; ".join(REASON_PLAIN[c] for c in result["reason_codes"] if c in REASON_PLAIN)
    return (
        f"RED alert: {p['name']} ({p['patient_id']}). Why: {why}. "
        f"At {sent_at} the family ({p['caregiver_name']}, her {p['caregiver_relation']}) was sent a message telling them to take her to "
        f"the nearest emergency department, with an emergency summary PDF for the receiving doctor. "
        f"Not yet known: whether she has reached an emergency department, and which one. "
        f"The coordinator has been asked to confirm within {PACKAGE_CONFIG['coordinator_call_within_minutes']} "
        f"minutes. Alert type: {kind}. Source: call audio and the PDF are linked on this card."
    )


def coordinator_task(seed, result, sent_at):
    p = seed["patient_profile"]
    mins = PACKAGE_CONFIG["coordinator_call_within_minutes"]
    return {
        "type": "CONFIRM_EMERGENCY_VISIT",
        "owner": "Care Coordinator (cover: Ravi)",
        "due_minutes": mins,
        "text": (
            f"Call {p['caregiver_name']} within {mins} minutes. Ask: has {first_name(p)} reached an "
            f"emergency department, and which one? Record the answer: REACHED (with hospital name), "
            f"NOT YET, REFUSED, or NOT REACHABLE. If the caregiver cannot be reached in 2 attempts, "
            f"tell the Doctor on Duty. Message and PDF were sent at {sent_at}."
        ),
    }


# ------------------------------------------------------------------ the PDF
def _arm_baseline(seed):
    a = seed["longitudinal_baseline"]["last_recorded_left_arm"]
    return f"{ARM_PLAIN.get(a['status'], a['status'])} (recorded {a['recorded_date']})"


NO_PLAIN = {
    "slurred_or_confused": "speech slurred or confusion",
    "cannot_stay_awake": "very hard to stay awake",
    "chest_pain": "chest pain or trouble breathing",
    "arm_red_or_hot": "left arm red or hot",
    "vomiting_count": None,
    "bangles_tighter": "bangles tighter than before",
}


def _today_lines(result, voice_note_translation):
    i = result["decision_inputs"]
    if "answers" in i and result["reason_codes"] != ["RED_NO_ANSWER_2X"]:
        said_no = [t for f, t in NO_PLAIN.items() if t and i["answers"].get(f) == triage.NO]
        lines = [triage.facts_text(result)]
        if said_no:
            lines.append("Asked and answered No: " + ", ".join(said_no) + ".")
        lines.append(
            "The call stopped at the first warning sign, so later questions were not asked."
            if result.get("confirmed_danger") and any(v == triage.NOT_ASKED for v in i["answers"].values())
            else ""
        )
        return [x for x in lines if x]
    lines = []
    if voice_note_translation:
        lines.append(f'Her voice message (machine translation from Tamil): "{voice_note_translation}"')
    lines.append("Two automated calls were not answered (5 minutes apart). No answers were recorded.")
    return lines


def render_summary_pdf(seed, result, path, sent_at, voice_note_translation=None):
    p, ch = seed["patient_profile"], seed["clinical_history"]
    ss = getSampleStyleSheet()
    body = ParagraphStyle("b", parent=ss["Normal"], fontName="Helvetica", fontSize=8.8, leading=11)
    small = ParagraphStyle("s", parent=body, fontSize=7.5, leading=9, textColor=colors.HexColor("#555555"))
    h = ParagraphStyle(
        "h",
        parent=body,
        fontName="Helvetica-Bold",
        fontSize=10,
        textColor=colors.HexColor("#1F3864"),
        spaceBefore=5,
        spaceAfter=2,
    )
    title = ParagraphStyle(
        "t", parent=body, fontName="Helvetica-Bold", fontSize=14, textColor=colors.white, leading=17
    )
    P = lambda t, st=body: Paragraph(t, st)
    box = lambda rows, w=(4.2 * cm, 13.0 * cm): Table(
        [[P("<b>%s</b>" % a), P(b)] for a, b in rows],
        colWidths=w,
        style=TableStyle(
            [
                ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#BBBBBB")),
                ("BACKGROUND", (0, 0), (0, -1), colors.HexColor("#F2F5FA")),
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
                ("TOPPADDING", (0, 0), (-1, -1), 2),
                ("BOTTOMPADDING", (0, 0), (-1, -1), 2),
            ]
        ),
    )

    kind = red_kind(result)
    why = "<br/>".join("&bull; " + REASON_PLAIN[c] for c in result["reason_codes"] if c in REASON_PLAIN)
    events = sorted(seed["events"], key=lambda e: e["timestamp"])
    hist = [
        [
            P("<b>Date</b>"),
            P("<b>What the patient reported</b>"),
            P("<b>Doctor's instruction and outcome</b>"),
        ]
    ]
    for e in events:
        hist.append(
            [
                P(e["timestamp"][:10]),
                P(e["patient_reported_facts"]),
                P((e.get("instruction_copied") or "No instruction recorded.") + " " + e["outcome_recorded"]),
            ]
        )
    histt = Table(
        hist,
        colWidths=[2.2 * cm, 7.0 * cm, 8.0 * cm],
        style=TableStyle(
            [
                ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#BBBBBB")),
                ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#F2F5FA")),
                ("VALIGN", (0, 0), (-1, -1), "TOP"),
            ]
        ),
    )
    meds = "<br/>".join(
        [
            f"&bull; {seed['care_plan']['maintenance_drug']['name']}: {seed['care_plan']['maintenance_drug']['schedule']}"
        ]
        + [f"&bull; {m['name']}: {m['schedule']}" for m in seed["care_plan"]["supplements"]]
        + ["&bull; No as-needed (SOS) medicines recorded."]
    )

    def on_page(c, d):
        c.saveState()
        c.setFont("Helvetica-Bold", 56)
        c.setFillColor(colors.Color(0.85, 0.85, 0.85, alpha=0.35))
        c.translate(10.5 * cm, 14 * cm)
        c.rotate(35)
        c.drawCentredString(0, 0, "SYNTHETIC DEMO")
        c.restoreState()
        c.saveState()
        c.setFont("Helvetica", 7.5)
        c.setFillColor(colors.HexColor("#555555"))
        c.drawString(
            2 * cm,
            1.35 * cm,
            "Generated by CarePilot's automated assistant from stored hospital records and the patient's own answers.",
        )
        c.drawString(
            2 * cm, 1.0 * cm, "It lists facts and the rules that fired. It does not diagnose or advise."
        )
        c.drawRightString(19 * cm, 0.7 * cm, f"Page {d.page}")
        c.restoreState()

    story = [
        Table(
            [[P("EMERGENCY SUMMARY FOR THE TREATING DOCTOR", title)]],
            colWidths=[17.2 * cm],
            style=TableStyle(
                [
                    ("BACKGROUND", (0, 0), (-1, -1), colors.HexColor("#B03A2E")),
                    ("TOPPADDING", (0, 0), (-1, -1), 8),
                    ("BOTTOMPADDING", (0, 0), (-1, -1), 8),
                ]
            ),
        ),
        Spacer(1, 4),
        P(
            f"<b>SYNTHETIC DEMO: not a real patient.</b> Prepared {sent_at} for the emergency doctor who receives this patient, "
            f"possibly at a different hospital. Facts come from the treating hospital's record and the patient's own answers.",
            small,
        ),
        P("1. Why she is being brought in", h),
        box(
            [
                (
                    "Alert type",
                    {
                        "CONFIRMED": "Warning signs in her answers",
                        "NO_ANSWER": "Reported symptoms, then could not be reached",
                        "UNCONFIRMED": "Answers could not be confirmed as safe",
                    }[kind],
                ),
                ("What triggered it", why),
            ]
        ),
        P("2. What she reported today", h),
        box([("Today", "<br/>".join(_today_lines(result, voice_note_translation)))]),
        P("3. Patient", h),
        box(
            [
                ("Name, age, sex", f"{p['name']}, {p['age']}, female"),
                ("Hospital ID", f"{p['patient_id']} at {ch['treating_hospital']}"),
                ("Language", "Tamil. The family speaks for her if she cannot."),
                ("Family contact", f"{p['caregiver_name']}, her {p['caregiver_relation']}"),
            ]
        ),
        P("4. Cancer history (from the treating hospital's record)", h),
        box(
            [
                ("Diagnosis", ch["diagnosis"]),
                ("Treatment done", "; ".join(ch["treatment_done"])),
                ("Active treatment finished", ch["active_treatment_completed"]),
                ("Now", ch["current_phase"]),
            ]
        ),
        P("5. Current medicines (from her care plan)", h),
        P(meds),
        P("6. Her last 30 days, from the record", h),
        histt,
        Spacer(1, 3),
        P(
            f"Last recorded left arm status: {_arm_baseline(seed)}. Last recorded headache score: "
            f"{seed['longitudinal_baseline']['last_recorded_headache']['pain_score_1_to_10']} out of 10 "
            f"({seed['longitudinal_baseline']['last_recorded_headache']['recorded_date']}).",
            body,
        ),
    ]
    for n in seed.get("emergency_notes_signed", []):
        story += [
            P("7. Note from her treating oncologist (word for word)", h),
            P(f"\"{n['text']}\""),
            P(f"Signed by {n['signed_by']}, {n['date_signed']}.", small),
        ]
    story += [
        P("8. Not recorded by CarePilot. Please ask the patient or family.", h),
        P(", ".join(ch["not_recorded"]) + "."),
        P("9. Contact the treating team", h),
        P(
            f"{ch['treating_hospital']} care team: {ch['care_team_phone']}. {ch['treating_oncologist']}. "
            f"Please call to share findings or ask for her records."
        ),
    ]
    SimpleDocTemplate(
        path,
        pagesize=A4,
        leftMargin=2 * cm,
        rightMargin=2 * cm,
        topMargin=1.1 * cm,
        bottomMargin=1.9 * cm,
        title="Emergency summary (synthetic)",
        author="CarePilot",
    ).build(story, onFirstPage=on_page, onLaterPages=on_page)
    return path


def build_red_package(seed, result, out_dir, demo_time, voice_note_translation=None):
    """Everything that goes out for a Red case. Returns the message, the PDF path, the notes and the audit rows."""
    import os

    os.makedirs(out_dir, exist_ok=True)
    sent_at = demo_time
    pdf = render_summary_pdf(
        seed, result, os.path.join(out_dir, "emergency_summary.pdf"), sent_at, voice_note_translation
    )
    msg, dnote, ctask = (
        caregiver_message(seed, result),
        doctor_note(seed, result, sent_at),
        coordinator_task(seed, result, sent_at),
    )
    audit = [
        {
            "actor_type": "AGENT",
            "action": "TEMPLATE_SENT",
            "template_id": TEMPLATE_ID,
            "to_role": "CAREGIVER",
            "attachment": "emergency_summary.pdf",
        },
        {
            "actor_type": "SYSTEM",
            "action": "DOCTOR_NOTE_CREATED",
            "to_role": "DOCTOR_ON_DUTY_AND_SENIOR_ONCOLOGIST",
        },
        {
            "actor_type": "SYSTEM",
            "action": "COORDINATOR_TASK_CREATED",
            "task_type": ctask["type"],
            "due_minutes": ctask["due_minutes"],
        },
    ]
    return {
        "kind": red_kind(result),
        "auto_send": red_kind(result) in PACKAGE_CONFIG["auto_send_kinds"],
        "message": msg,
        "pdf_path": pdf,
        "doctor_note": dnote,
        "coordinator_task": ctask,
        "audit_rows": audit,
    }
