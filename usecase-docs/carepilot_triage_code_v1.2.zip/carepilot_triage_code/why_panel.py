"""The "Why this tier" panel. Mechanical: every line is built from a rule that fired plus stored history."""

import triage
from red_package import REASON_PLAIN

PLAIN_AMBER = {  # fixed sentences for Amber reasons that need no numbers from her history
    "AMBER_DROWSY_MOST_OF_TODAY": "She says she felt sleepy or groggy for most of today.",
    "AMBER_ARM_SWOLLEN": "She says the left arm looks swollen or feels heavy.",
    "AMBER_SKIN_BREAK_LEFT_ARM": "She reports a cut, bite or prick on the left arm.",
    "AMBER_THREE_OR_MORE_SYMPTOMS_NOW": "Three or more symptoms are present now.",
    "AMBER_ARM_PAIN_SUDDEN_ONSET": "She says the left arm pain started suddenly.",
    "AMBER_TIREDNESS_GETTING_WORSE": "She says the tiredness is worse than last week.",
    "AMBER_PATIENT_SAYS_SEVERE": "She described her problem as severe in her own message.",
    "AMBER_OTHER_SYMPTOM_REPORTED": "She reported a problem that is not on our question list. A nurse will call.",
    "AMBER_NURSE_REQUESTED": "She asked to speak to a nurse.",
    "AMBER_TRANSCRIPT_UNUSABLE": "Her answers could not be turned into text.",
    "AMBER_ROLE_NOT_CONFIRMED": "We could not confirm who was speaking.",
    "AMBER_CAREGIVER_NO_CONSENT": "A family member answered and family updates are not consented.",
    "AMBER_NO_ANSWER_ON_FOLLOWUP": "The follow-up call was not answered twice.",
    "AMBER_NOT_BETTER_AFTER_24H": "At the follow-up call she said she was not better.",
    "AMBER_REOPENED_NOT_BETTER": "At the follow-up call she said she was not better. The ticket was reopened.",
}


def why_lines(seed, result):
    """Returns plain-English lines that compare today's answers with her history. No interpretation."""
    base = seed["longitudinal_baseline"]
    arm, head = base["last_recorded_left_arm"], base["last_recorded_headache"]
    i = result["decision_inputs"]
    a = i.get("answers", {})
    advice = next(
        (x for x in seed.get("clinician_repeatable_instructions", []) if x.get("patient_repeatable")), None
    )
    lines = []
    for code in result["reason_codes"]:
        if code in REASON_PLAIN:
            lines.append(REASON_PLAIN[code])
        elif code == "AMBER_BANGLES_TIGHTER_THAN_BASELINE":
            lines.append(
                f"Left arm: no swelling and loose bangles on {arm['recorded_date']}. Today: bangles tighter."
            )
        elif code == "AMBER_HEADACHE_RISE_2_PLUS":
            lines.append(
                f"Headache: {head['pain_score_1_to_10']} out of 10 on {head['recorded_date']}. "
                f"Today: {i['headache_score_used']} out of 10."
            )
        elif code == "AMBER_HEADACHE_WORSE_THAN_LAST_TIME":
            lines.append(f"She says the headache is worse than on {head['recorded_date']}.")
        elif code == "AMBER_NAUSEA_DESPITE_MEALS" and advice:
            lines.append(
                f"She still feels sick although she says she took her supplements only after full meals, "
                f"as the doctor advised on {advice['date_authored']}."
            )
        elif code.startswith("AMBER_RECURRING_3X_14D_"):
            sym = code.rsplit("_", 1)[1].lower().replace("arm_pain", "arm pain")
            lines.append(
                f"This is the third report of {sym.replace('_', ' ')} in 14 days (earlier reports: {i['rolling_counts']})."
            )
        elif code in PLAIN_AMBER:
            lines.append(PLAIN_AMBER[code])
        elif code == "AMBER_ARM_PAIN_7_PLUS":
            lines.append(f"Left arm pain reported as {int(a['arm_pain_score'])} out of 10.")
        elif code == "AMBER_TIREDNESS_7_DAYS_PLUS":
            lines.append(f"Tiredness reported for {int(a['tired_days'])} days.")
        elif code == "AMBER_VOMITING_2_TO_5":
            lines.append(f"Vomited {int(a['vomiting_count'])} times since yesterday.")
        elif code == "AMBER_NO_THERMOMETER_WITH_SYMPTOMS":
            lines.append("No temperature reading, and she has symptoms.")
        elif code == "AMBER_FEELS_HOT_NO_THERMOMETER":
            lines.append("She feels hot and has no temperature reading.")
        elif code == "AMBER_HEADACHE_48H_PLUS":
            lines.append("Headache for 48 hours or more.")
        elif code == "AMBER_CANNOT_CONFIRM":
            lines.append(
                "Some answers could not be confirmed: " + ", ".join(i.get("unconfirmed_fields", [])) + "."
            )
        else:
            lines.append(code)
    if result["tier"] == "TIER_3_GREEN":
        lines = ["No rule fired. " + triage.facts_text(result)]
    return lines
