"""The Triage Room: the logic behind the staff screen. One ticket for every message that was triaged.

Staff only. The patient never sees it. Every line on it is a stored fact or a fixed sentence.
"""

import wave

import triage
import why_panel

ROLES = ("COORDINATOR", "DOCTOR_ON_DUTY", "NURSE", "ER_DOCTOR", "AGENT")
RANK = {"TIER_3_GREEN": 0, "TIER_2_AMBER": 1, "TIER_1_RED": 2}
COLOUR = {"TIER_3_GREEN": "GREEN", "TIER_2_AMBER": "AMBER", "TIER_1_RED": "RED"}
STATES = ("IN_DIGEST", "OPEN", "ACKNOWLEDGED", "OUTCOME_LOGGED", "CLOSURE_PROPOSED", "CLOSED", "REOPENED")
# state -> states it may move to
MOVES = {
    "IN_DIGEST": {"ACKNOWLEDGED", "REOPENED"},
    "OPEN": {"ACKNOWLEDGED"},
    "ACKNOWLEDGED": {"OUTCOME_LOGGED", "CLOSURE_PROPOSED"},
    "OUTCOME_LOGGED": {"CLOSURE_PROPOSED", "CLOSED"},
    "CLOSURE_PROPOSED": {"CLOSED", "REOPENED"},
    "CLOSED": {"REOPENED"},
    "REOPENED": {"OPEN"},
}
# Which role may do which move on which tier
WHO_MAY_ACK = {"TIER_3_GREEN": {"COORDINATOR"}, "TIER_2_AMBER": {"DOCTOR_ON_DUTY", "NURSE", "COORDINATOR"},
                "TIER_1_RED": {"NURSE", "ER_DOCTOR"}}  # fmt: skip
WHO_MAY_CLOSE = {
    "TIER_2_AMBER": {"DOCTOR_ON_DUTY", "COORDINATOR"},
    "TIER_1_RED": {"ER_DOCTOR"},
}  # the agent never closes these
WHO_MAY_LOWER = {
    "TIER_2_AMBER": {"DOCTOR_ON_DUTY", "ER_DOCTOR"},
    "TIER_1_RED": {"ER_DOCTOR"},
}  # keyed by the CURRENT tier


def ticket_id(day_iso, seq):
    """CP-20261027-0001: the demo date and a number that restarts each day."""
    return f"CP-{day_iso[:10].replace('-', '')}-{seq:04d}"


# ---------------------------------------------------------------- next action for each person
def _kind(result):
    code = result.get("action_code")
    return {
        "GREEN_COACH_AND_FOLLOWUP_24H": "GREEN", "DOCTOR_CALLBACK_2H": "AMBER",
        "COORDINATOR_IMMEDIATE_CALLBACK": "AMBER_NURSE_NOW", "ER_DESK_HANDOFF_SIMULATED": "RED_CONFIRMED",
        "ALERT_NURSE_AND_CALL_CAREGIVER": "RED_NO_ANSWER", "NURSE_CALLBACK_NOW": "RED_UNCONFIRMED",
    }.get(code, "AMBER")  # fmt: skip


def next_actions(result):
    """What the AI did and what each person does next, in plain words, with a due time and buttons."""
    k = _kind(result)
    done = lambda text: {"text": text, "due_minutes": None, "buttons": []}
    todo = lambda text, due, *buttons: {"text": text, "due_minutes": due, "buttons": list(buttons)}
    nothing = done("Nothing to do.")
    if k == "GREEN":
        return {
            "AI": done("Repeated the doctor's signed sentence if one fits. Will call again tomorrow morning."),
            "DOCTOR": nothing, "NURSE": nothing,
            "COORDINATOR": todo("Acknowledge the digest line within 1 working day. Reopen it if something looks wrong.",
                                1440, "Acknowledge", "Reopen"),
        }  # fmt: skip
    if k == "AMBER":
        return {
            "AI": done("Told her a doctor will call within 2 hours. Will call again 24 hours after the doctor logs the outcome."),
            "DOCTOR": todo("Call her within 2 hours. Log the outcome. Choose an order if one is needed. Confirm closure after the 24-hour call.",
                           120, "Call done", "Log outcome", "Physiotherapy referral", "Bring forward blood tests",
                           "No order needed", "Raise or lower tier", "Confirm closure"),
            "NURSE": done("Nothing, unless she presses 0 on a call."),
            "COORDINATOR": todo("Book the order the doctor picks. If no doctor has acted in 90 minutes, you and the cover are alerted.",
                                90, "Book order", "Raise tier"),
        }  # fmt: skip
    if k == "AMBER_NURSE_NOW":
        return {
            "AI": done("Told her a nurse will call within 15 minutes. No health questions were scored."),
            "DOCTOR": done("Aware only. Called if the nurse asks."),
            "NURSE": todo("Call her back within 15 minutes. Find out how she is.", 15, "Call done", "Raise tier"),
            "COORDINATOR": todo("If the nurse cannot reach her in 2 attempts, tell the Doctor on Duty.", 30, "Tell doctor"),
        }  # fmt: skip
    pkg = "Sent the family the emergency message and PDF summary. Wrote the doctor note. Created the coordinator task."
    ack = todo("Acknowledge the alert now.", 1, "Acknowledge")
    coord = todo("Call the family within 30 minutes. Has she reached an emergency department, and which one? Record the answer.",
                 30, "REACHED", "NOT YET", "REFUSED", "NOT REACHABLE")  # fmt: skip
    close = todo(
        "Record what was done. Only the ER doctor can close a Red case.",
        None,
        "Log what was done",
        "Close case",
    )
    if k == "RED_CONFIRMED":
        return {"AI": done(pkg), "DOCTOR": close, "NURSE": ack, "COORDINATOR": coord}
    if k == "RED_NO_ANSWER":
        return {
            "AI": done("Two calls were not answered. " + pkg),
            "DOCTOR": close,
            "NURSE": ack,
            "COORDINATOR": coord,
        }
    return {  # RED_UNCONFIRMED
        "AI": done("Could not confirm she is safe. Told her a nurse will call. No family message was sent yet."),
        "DOCTOR": todo("Aware. Only the ER doctor can close a Red case.", None, "Close case"),
        "NURSE": todo("Call her back within 15 minutes. If you cannot confirm she is safe, send the emergency package.",
                      15, "Call done", "Send emergency package"),
        "COORDINATOR": todo("Help the nurse reach her or the family.", 15, "Log call"),
    }  # fmt: skip


# ---------------------------------------------------------------- the ticket
FACT_LINKS = [  # prefix of a summary fact -> the question it came from (to jump to that moment in the audio)
    ("Headache", "Q_HEAD_SCORE"), ("Nausea", "Q_NAUSEA"), ("Vomited", "Q_VOMIT"), ("Sleepy", "Q_DROWSY"),
    ("Bangles", "Q_BANGLES"), ("Left arm swollen", "Q_SWOLLEN"), ("Left arm red", "Q_ARM_RED"),
    ("Left arm pain", "Q_ARM_SCORE"), ("Arm pain started", "Q_ARM_SUDDEN"), ("Thermometer", "Q_TEMP"),
    ("No thermometer", "Q_TEMP"), ("Tired for", "Q_TIRED_DAYS"), ("Tiredness", "Q_TIRED_WORSE"),
    ("Slurred", "Q_SLURRED"), ("Very hard to stay awake", "Q_AWAKE"), ("Chest pain", "Q_CHEST"),
    ("Cut or bite", "Q_SKIN"), ("Feels hot", "Q_FEELS_HOT"), ("Shaking chills", "Q_CHILLS"),
]  # fmt: skip


def summary_lines(result, timeline=None):
    """Facts only, one per line, each linked to the moment in the audio where she said it."""
    start = {t["question_id"]: t["start_s"] for t in (timeline or []) if t.get("question_id")}
    lines = []
    for fact in triage.facts_text(result).rstrip(".").split("; "):
        qid = next((q for p, q in FACT_LINKS if fact.startswith(p)), None)
        lines.append({"text": fact, "question_id": qid, "audio_start_s": start.get(qid)})
    return lines


def build_ticket(seed, plan, result, seq, created_iso, timeline=None, audio_path=None, voice_note=None):
    p = seed["patient_profile"]
    green = result["tier"] == "TIER_3_GREEN"
    asked = list(plan.get("question_ids", []))
    t = {
        "ticket_id": ticket_id(created_iso, seq), "created_at": created_iso, "data_label": p["data_label"],
        "patient": {"name": p["name"], "patient_id": p["patient_id"], "age": p["age"]},
        "tier": result["tier"], "colour": COLOUR[result["tier"]], "state": "IN_DIGEST" if green else "OPEN",
        "due_minutes": result.get("response_minutes"), "reason_codes": result["reason_codes"],
        "why_lines": why_panel.why_lines(seed, result), "summary_lines": summary_lines(result, timeline),
        "questions_asked": asked, "modules": plan.get("modules", []),
        "conversation_audio": {"path": audio_path, "timeline": timeline or []},
        "voice_note": voice_note, "next_actions": next_actions(result),
        "protocol": {"id": result["protocol_id"], "status": result["protocol_status"], "profile": result["protocol_profile"]},
        "audit": [{"actor_type": "SYSTEM", "actor": "protocol_v1", "action": "TICKET_CREATED", "state": "IN_DIGEST" if green else "OPEN"}],
    }  # fmt: skip
    return t


def _log(ticket, role, action, **extra):
    ticket["audit"].append(
        {"actor_type": "AGENT" if role == "AGENT" else "PERSON", "actor": role, "action": action, **extra}
    )


def move(ticket, new_state, role):
    """Change the ticket's state. Raises ValueError when the role may not do it."""
    if new_state not in MOVES.get(ticket["state"], set()):
        raise ValueError(f"{ticket['state']} cannot move to {new_state}")
    tier = ticket["tier"]
    if new_state == "CLOSED":
        if role == "AGENT" or role not in WHO_MAY_CLOSE.get(tier, set()):
            raise ValueError(f"{role} may not close a {COLOUR[tier]} ticket")
        if tier == "TIER_2_AMBER" and ticket["state"] != "CLOSURE_PROPOSED":
            raise ValueError("An Amber ticket is closed only after the 24-hour call proposes closure")
    if new_state == "ACKNOWLEDGED" and role not in WHO_MAY_ACK.get(tier, set()):
        raise ValueError(f"{role} may not acknowledge a {COLOUR[tier]} ticket")
    if new_state == "CLOSURE_PROPOSED" and role != "AGENT":
        raise ValueError("Only the agent proposes closure; a person then confirms it")
    ticket["state"] = new_state
    _log(ticket, role, "STATE_" + new_state)
    return ticket


def change_tier(ticket, role, new_tier, reason):
    """Anyone on the team may raise a tier. Only a doctor may lower it, and Red only the ER doctor. A reason is required."""
    if not reason or not reason.strip():
        raise ValueError("A reason is required")
    old = ticket["tier"]
    if RANK[new_tier] == RANK[old]:
        raise ValueError("The tier is already " + COLOUR[old])
    if role == "AGENT":
        raise ValueError("The agent cannot change a tier")
    if RANK[new_tier] < RANK[old] and role not in WHO_MAY_LOWER.get(old, set()):
        raise ValueError(f"{role} may not lower a {COLOUR[old]} ticket")
    ticket["tier"], ticket["colour"] = new_tier, COLOUR[new_tier]
    _log(ticket, role, "TIER_CHANGED", old=COLOUR[old], new=COLOUR[new_tier], reason=reason)
    return ticket


# ---------------------------------------------------------------- the whole conversation as one audio file
def stitch_conversation_wav(turns, out_path, gap_s=0.6):
    """turns: [{"speaker": "AI" or "PATIENT", "question_id": "Q_...", "path": "x.wav"}, ...] in the order they happened.
    Writes one WAV file with a short silence between turns. Returns the timeline so a summary line can jump to its moment.
    """
    params, frames, timeline, t = None, [], [], 0.0
    for turn in turns:
        with wave.open(turn["path"], "rb") as w:
            p = (w.getnchannels(), w.getsampwidth(), w.getframerate())
            if params is None:
                params = p
            elif p != params:
                raise ValueError("All clips must have the same format (channels, width, sample rate)")
            data = w.readframes(w.getnframes())
            dur = w.getnframes() / w.getframerate()
        gap = b"\x00" * (int(gap_s * params[2]) * params[0] * params[1])
        timeline.append({"speaker": turn["speaker"], "question_id": turn.get("question_id"),
                         "start_s": round(t, 2), "end_s": round(t + dur, 2)})  # fmt: skip
        frames += [data, gap]
        t += dur + gap_s
    with wave.open(out_path, "wb") as out:
        out.setnchannels(params[0]); out.setsampwidth(params[1]); out.setframerate(params[2])  # fmt: skip
        out.writeframes(b"".join(frames))
    return timeline
